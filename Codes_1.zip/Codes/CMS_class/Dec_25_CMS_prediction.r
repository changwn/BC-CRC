library(synapseClient)
library(CMSclassifier)

synapseLogin()

sampleData <- read.table(synGet("syn4983432")@filePath, sep="\t",header = TRUE,row.names = 1,check.names=FALSE)

Rfcms <- CMSclassifier::classifyCMS(t(sampleData),method="RF")[[3]]
SScms <- CMSclassifier::classifyCMS(t(sampleData),method="SSP")[[3]]
aaa<-CMSclassifier::classifyCMS(t(sampleData),method="RF")

sampleData0<-sampleData[,-1]
Rfcms <- CMSclassifier::classifyCMS(t(sampleData0),method="RF")[[3]]

CMSclassifier_training_data_running_data<-sampleData
CMSclassifier_training_data_results<-aaa[[3]]

save(list=c("CMSclassifier_training_data_results",
"CMSclassifier_training_data_running_data"),
file="CMSclassifier_training_data_results.RData")

load("TCGA_GI_Symbol.RData")

dim(sampleData)
TCGA_GI_Symbol<-rbind(TCGA_GI_Symbol,c("OCLN","100506658"))
rownames(TCGA_GI_Symbol)[20530]<-"100506658"
TCGA_GI_Symbol0<-TCGA_GI_Symbol
rownames(TCGA_GI_Symbol0)<-TCGA_GI_Symbol0[,1]

length(intersect(colnames(sampleData),TCGA_GI_Symbol[,2]))
setdiff(colnames(sampleData),TCGA_GI_Symbol[,2])

load("c:/chizhang/Functions6.RData")
tg_genes_ref0<-TCGA_GI_Symbol[intersect(colnames(sampleData),TCGA_GI_Symbol[,2]),1]
tg_genes_570<-intersect(tg_genes_ref0,unique(as.character(GPL570_id_symbol[,2])))
tg_genes_570_GI<-as.character(TCGA_GI_Symbol0[tg_genes_570,2])
tg_genes_570_GI_info<-cbind(tg_genes_570,TCGA_GI_Symbol0[tg_genes_570,2])


sampleData0<-sampleData[,tg_genes_570_GI]
dim(sampleData0)
Rfcms <- CMSclassifier::classifyCMS(t(sampleData0),method="RF")[[3]]

sum(Rfcms[,5]==CMSclassifier_training_data_results[,5])
sum(Rfcms[,5]!=CMSclassifier_training_data_results[,5])

test_training_data0<-t(sampleData0)

#################################################
tg_data_list<-list.files("C:/chizhang/2016_Nov_Sen_Liang_QB_CRC/GEO-RData",pattern="GPL570")
rm(d.matrix)
CMS_prediction_GPL570RMA<-list()
CMS_prediction_GPL570RMA_scaleddata<-list()
for(ii in 1:length(tg_data_list))
{
	print(tg_data_list[ii])
	tg_data_R<-paste("C:/chizhang/2016_Nov_Sen_Liang_QB_CRC/GEO-RData/",tg_data_list[ii],sep="")
	load(tg_data_R)
	tg_genes_570_GI_info_cdata<-cbind(tg_genes_570_GI_info,tg_genes_570_GI_info)
	tg_genes_570_GI_info_cdata[,3]<-""
	tg_genes_570_GI_info_cdata[,4]<-""
	colnames(tg_genes_570_GI_info_cdata)<-c("Symbol","GI","tg_probe","Total_N_probe")
	tg_data_m<-apply(tg_data,1,median)
	for(i in 1:nrow(tg_genes_570_GI_info_cdata))
	{
		if(i%%1000==1)
		{
			print(c(i,nrow(tg_genes_570_GI_info_cdata)))
		}
		tg_gene_c<-tg_genes_570_GI_info_cdata[i,1]
		tg_probe_ids<-GPL570_id_symbol[which(GPL570_id_symbol[,2]==tg_gene_c),1]
		if(length(tg_probe_ids)==1)
		{
			tg_genes_570_GI_info_cdata[i,3]<-tg_probe_ids
			tg_genes_570_GI_info_cdata[i,4]<-1
		}
		else
		{
			tg_genes_570_GI_info_cdata[i,3]<-tg_probe_ids[which(tg_data_m[tg_probe_ids]==max(tg_data_m[tg_probe_ids]))][1]
			tg_genes_570_GI_info_cdata[i,4]<-length(tg_probe_ids)
		}
	}
	GPL570_id_symbol0<-GPL570_id_symbol
	rownames(GPL570_id_symbol0)<-GPL570_id_symbol[,1]
	print(sum(tg_genes_570_GI_info_cdata[,1]==GPL570_id_symbol0[tg_genes_570_GI_info_cdata[,3],2]))
	tg_data_selected_GI<-d.matrix[tg_genes_570_GI_info_cdata[,3],]
	rownames(tg_data_selected_GI)<-tg_genes_570_GI_info_cdata[,2]
	print(dim(tg_data_selected_GI))
	print(c(sum(rownames(test_training_data0)==rownames(tg_data_selected_GI)),5966))
	Rfcms_tg_data <- CMSclassifier::classifyCMS(tg_data_selected_GI,method="RF")[[3]]
	tg_data_m<-apply(tg_data_selected_GI,1,mean)
	tg_data_s<-apply(tg_data_selected_GI,1,sd)
	testing_data_m<-apply(test_training_data0,1,mean)
	testing_data_s<-apply(test_training_data0,1,sd)
	tg_data_m_m<-matrix(tg_data_m,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
	tg_data_s_m<-matrix(tg_data_s,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
	testing_data_m_m<-matrix(testing_data_m,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
	testing_data_s_m<-matrix(testing_data_s,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
	tg_data_selected_GI_normalized<-(tg_data_selected_GI-tg_data_m_m)/tg_data_s_m*testing_data_s_m+testing_data_m_m
	Rfcms_tg_data_normalized <- CMSclassifier::classifyCMS(tg_data_selected_GI_normalized,method="RF")[[3]]
	CMS_prediction_GPL570RMA[[ii]]<-Rfcms_tg_data
	CMS_prediction_GPL570RMA_scaleddata[[ii]]<-Rfcms_tg_data_normalized 
	rm(tg_data_selected_GI)
	rm(d.matrix)
	rm(Rfcms_tg_data)
	rm(Rfcms_tg_data_normalized)
	rm(tg_data_selected_GI_normalized)
}
names(CMS_prediction_GPL570RMA)<-tg_data_list
names(CMS_prediction_GPL570RMA_scaleddata)<-tg_data_list

CMS_prediction_training_data<-Rfcms
agrep("TCGA",rownames(CMS_prediction_training_data),max.distance=0)
rownames(CMS_prediction_training_data)[agrep("TCGA",rownames(CMS_prediction_training_data),max.distance=0)]
CMS_prediction_TCGA<-CMS_prediction_training_data[agrep("TCGA",rownames(CMS_prediction_training_data),max.distance=0),]
load("c:/chizhang/Functions5.RData")
rownames(CMS_prediction_TCGA)<-edit_colnames3(rownames(CMS_prediction_TCGA))
save(list=c("CMS_prediction_GPL570RMA_scaleddata","CMS_prediction_GPL570RMA",
"CMS_prediction_TCGA","CMS_prediction_training_data"),file="CMS_prediction_results_GPL570.RData")
