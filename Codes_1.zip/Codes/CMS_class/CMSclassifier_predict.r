library(synapseClient)
library(CMSclassifier)

synapseLogin()

sampleData <- read.table(synGet("syn4983432")@filePath, sep="\t",header = TRUE,row.names = 1,check.names=FALSE)

Rfcms <- CMSclassifier::classifyCMS(t(sampleData),method="RF")[[3]]
SScms <- CMSclassifier::classifyCMS(t(sampleData),method="SSP")[[3]]
aaa<-CMSclassifier::classifyCMS(t(sampleData),method="RF")

sampleData0<-sampleData[,-1]
Rfcms <- CMSclassifier::classifyCMS(t(sampleData0),method="RF")[[3]]

CMSclassifier_training_data_running_data<-sampleData
CMSclassifier_training_data_results<-aaa[[3]]

save(list=c("CMSclassifier_training_data_results",
"CMSclassifier_training_data_running_data"),
file="CMSclassifier_training_data_results.RData")

load("TCGA_GI_Symbol.RData")

dim(sampleData)
TCGA_GI_Symbol<-rbind(TCGA_GI_Symbol,c("OCLN","100506658"))
rownames(TCGA_GI_Symbol)[20530]<-"100506658"
TCGA_GI_Symbol0<-TCGA_GI_Symbol
rownames(TCGA_GI_Symbol0)<-TCGA_GI_Symbol0[,1]

length(intersect(colnames(sampleData),TCGA_GI_Symbol[,2]))
setdiff(colnames(sampleData),TCGA_GI_Symbol[,2])


CMS_genes<-as.character(TCGA_GI_Symbol[intersect(colnames(sampleData),TCGA_GI_Symbol[,2]),1])
save(list="CMS_genes",file="CMS_genes.RData")

load("c:/chizhang/Functions6.RData")
tg_genes_ref0<-TCGA_GI_Symbol[intersect(colnames(sampleData),TCGA_GI_Symbol[,2]),1]
tg_genes_570<-intersect(tg_genes_ref0,unique(as.character(GPL570_id_symbol[,2])))
tg_genes_570_GI<-as.character(TCGA_GI_Symbol0[tg_genes_570,2])
tg_genes_570_GI_info<-cbind(tg_genes_570,TCGA_GI_Symbol0[tg_genes_570,2])


sampleData0<-sampleData[,tg_genes_570_GI]
dim(sampleData0)
Rfcms <- CMSclassifier::classifyCMS(t(sampleData0),method="RF")[[3]]

sum(Rfcms[,5]==CMSclassifier_training_data_results[,5])
sum(Rfcms[,5]!=CMSclassifier_training_data_results[,5])


#################################################
list.files("C:/chizhang/2016_Nov_Sen_Liang_QB_CRC/CRC-GSE-DATA")

load("C:/chizhang/2016_Nov_Sen_Liang_QB_CRC/CRC-GSE-DATA/GSE14333_GPL570_RMA_normalized_step2.probe.nomap.RData")
tg_samples<-colnames(d.matrix)
tg_samples0<-intersect(tg_samples,rownames(sampleData))
test_training_data<-t(as.matrix(sampleData[tg_samples0,]))
test_training_data0<-test_training_data[tg_genes_570_GI,]
dim(test_training_data0)
tg_data<-d.matrix[,tg_samples0]

tg_genes_570_GI_info_cdata<-cbind(tg_genes_570_GI_info,tg_genes_570_GI_info)
tg_genes_570_GI_info_cdata[,3]<-""
tg_genes_570_GI_info_cdata[,4]<-""
colnames(tg_genes_570_GI_info_cdata)<-c("Symbol","GI","tg_probe","Total_N_probe")
tg_data_m<-apply(tg_data,1,median)
for(i in 1:nrow(tg_genes_570_GI_info_cdata))
{
	tg_gene_c<-tg_genes_570_GI_info_cdata[i,1]
	tg_probe_ids<-GPL570_id_symbol[which(GPL570_id_symbol[,2]==tg_gene_c),1]
	if(length(tg_probe_ids)==1)
	{
		tg_genes_570_GI_info_cdata[i,3]<-tg_probe_ids
		tg_genes_570_GI_info_cdata[i,4]<-1
	}
	else
	{
		tg_genes_570_GI_info_cdata[i,3]<-tg_probe_ids[which(tg_data_m[tg_probe_ids]==max(tg_data_m[tg_probe_ids]))][1]
		tg_genes_570_GI_info_cdata[i,4]<-length(tg_probe_ids)
	}
}

GPL570_id_symbol0<-GPL570_id_symbol
rownames(GPL570_id_symbol0)<-GPL570_id_symbol[,1]
sum(tg_genes_570_GI_info_cdata[,1]==GPL570_id_symbol0[tg_genes_570_GI_info_cdata[,3],2])
dim(tg_genes_570_GI_info_cdata)
tg_data_selected_GI<-tg_data[tg_genes_570_GI_info_cdata[,3],]
rownames(tg_data_selected_GI)<-tg_genes_570_GI_info_cdata[,2]

dim(test_training_data0)
dim(tg_data_selected_GI)
sum(rownames(tg_data_selected_GI)==rownames(test_training_data0))
sum(colnames(tg_data_selected_GI)==colnames(test_training_data0))

ccc<-cor(tg_data_selected_GI,test_training_data0)

library(gplots)
colors = c(-100:100)/100
my_palette <- colorRampPalette(c("red", "white", "blue"))(n = length(colors)-1)

colors = c(80:100)/100
my_palette <- colorRampPalette(c("white", "blue"))(n = length(colors)-1)

h<-heatmap.2(ccc,Rowv=F,Colv =F,scale="none",
col=my_palette,breaks=colors,density.info="none",dendrogram="none",trace="none",margin=c(5,5),cexRow=0.4,cexCol=0.4,
key.par=list(mgp=c(5, 0.5, 0),mar=c(1, 2.5, 1, 1)), lmat=rbind( c(0, 3), c(2,1 ) ,c(0,4)),lhei = c(1,4,0.5))


###################################

Rfcms_tg_data <- CMSclassifier::classifyCMS(tg_data_selected_GI,method="RF")[[3]]
Rfcms_testing_data <- CMSclassifier::classifyCMS(test_training_data0,method="RF")[[3]]
Rfcms_testing_data[,5]==Rfcms_tg_data[,5]

tg_data_m<-apply(tg_data_selected_GI,1,mean)
tg_data_s<-apply(tg_data_selected_GI,1,sd)
testing_data_m<-apply(test_training_data0,1,mean)
testing_data_s<-apply(test_training_data0,1,sd)

tg_data_m_m<-matrix(tg_data_m,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
tg_data_s_m<-matrix(tg_data_s,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
testing_data_m_m<-matrix(testing_data_m,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
testing_data_s_m<-matrix(testing_data_s,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)

tg_data_selected_GI_normalized<-(tg_data_selected_GI-tg_data_m_m)/tg_data_s_m*testing_data_s_m+testing_data_m_m

ccc<-cor(tg_data_selected_GI_normalized,test_training_data0)

colors = c(80:100)/100
my_palette <- colorRampPalette(c("white", "blue"))(n = length(colors)-1)

h<-heatmap.2(ccc,Rowv=F,Colv =F,scale="none",
col=my_palette,breaks=colors,density.info="none",dendrogram="none",trace="none",margin=c(5,5),cexRow=0.4,cexCol=0.4,
key.par=list(mgp=c(5, 0.5, 0),mar=c(1, 2.5, 1, 1)), lmat=rbind( c(0, 3), c(2,1 ) ,c(0,4)),lhei = c(1,4,0.5))

Rfcms_tg_data_normalized <- CMSclassifier::classifyCMS(tg_data_selected_GI_normalized,method="RF")[[3]]
Rfcms_testing_data[,5]==Rfcms_tg_data[,5]
par(mfcol=c(1,2))
boxplot(apply(Rfcms_tg_data_normalized[,1:4],1,max)~Rfcms_tg_data_normalized[,5]==Rfcms_testing_data[,5],main="New_Normalized\ndata_prediction")
boxplot(apply(Rfcms_testing_data[,1:4],1,max)~Rfcms_tg_data_normalized[,5]==Rfcms_testing_data[,5],main="Original_data\nprediction")


#################################################
list.files("C:/chizhang/2016_Nov_Sen_Liang_QB_CRC/CRC-GSE-DATA")

load("C:/chizhang/2016_Nov_Sen_Liang_QB_CRC/CRC-GSE-DATA/GSE17536_GPL570_RMA_normalized_step2.probe.nomap.RData")
tg_samples<-colnames(d.matrix)
tg_samples0<-intersect(tg_samples,rownames(sampleData))
test_training_data<-t(as.matrix(sampleData[tg_samples0,]))
test_training_data0<-test_training_data[tg_genes_570_GI,]
dim(test_training_data0)
tg_data<-d.matrix[,tg_samples0]

tg_genes_570_GI_info_cdata<-cbind(tg_genes_570_GI_info,tg_genes_570_GI_info)
tg_genes_570_GI_info_cdata[,3]<-""
tg_genes_570_GI_info_cdata[,4]<-""
colnames(tg_genes_570_GI_info_cdata)<-c("Symbol","GI","tg_probe","Total_N_probe")
tg_data_m<-apply(tg_data,1,median)
for(i in 1:nrow(tg_genes_570_GI_info_cdata))
{
	tg_gene_c<-tg_genes_570_GI_info_cdata[i,1]
	tg_probe_ids<-GPL570_id_symbol[which(GPL570_id_symbol[,2]==tg_gene_c),1]
	if(length(tg_probe_ids)==1)
	{
		tg_genes_570_GI_info_cdata[i,3]<-tg_probe_ids
		tg_genes_570_GI_info_cdata[i,4]<-1
	}
	else
	{
		tg_genes_570_GI_info_cdata[i,3]<-tg_probe_ids[which(tg_data_m[tg_probe_ids]==max(tg_data_m[tg_probe_ids]))][1]
		tg_genes_570_GI_info_cdata[i,4]<-length(tg_probe_ids)
	}
}

GPL570_id_symbol0<-GPL570_id_symbol
rownames(GPL570_id_symbol0)<-GPL570_id_symbol[,1]
sum(tg_genes_570_GI_info_cdata[,1]==GPL570_id_symbol0[tg_genes_570_GI_info_cdata[,3],2])
dim(tg_genes_570_GI_info_cdata)
tg_data_selected_GI<-tg_data[tg_genes_570_GI_info_cdata[,3],]
rownames(tg_data_selected_GI)<-tg_genes_570_GI_info_cdata[,2]

dim(test_training_data0)
dim(tg_data_selected_GI)
sum(rownames(tg_data_selected_GI)==rownames(test_training_data0))
sum(colnames(tg_data_selected_GI)==colnames(test_training_data0))

ccc<-cor(tg_data_selected_GI,test_training_data0)

library(gplots)
colors = c(-100:100)/100
my_palette <- colorRampPalette(c("red", "white", "blue"))(n = length(colors)-1)

colors = c(80:100)/100
my_palette <- colorRampPalette(c("white", "blue"))(n = length(colors)-1)

h<-heatmap.2(ccc,Rowv=F,Colv =F,scale="none",
col=my_palette,breaks=colors,density.info="none",dendrogram="none",trace="none",margin=c(5,5),cexRow=0.4,cexCol=0.4,
key.par=list(mgp=c(5, 0.5, 0),mar=c(1, 2.5, 1, 1)), lmat=rbind( c(0, 3), c(2,1 ) ,c(0,4)),lhei = c(1,4,0.5))

###################################

Rfcms_tg_data <- CMSclassifier::classifyCMS(tg_data_selected_GI,method="RF")[[3]]
Rfcms_testing_data <- CMSclassifier::classifyCMS(test_training_data0,method="RF")[[3]]
Rfcms_testing_data[,5]==Rfcms_tg_data[,5]

tg_data_m<-apply(tg_data_selected_GI,1,mean)
tg_data_s<-apply(tg_data_selected_GI,1,sd)
testing_data_m<-apply(test_training_data0,1,mean)
testing_data_s<-apply(test_training_data0,1,sd)

tg_data_m_m<-matrix(tg_data_m,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
tg_data_s_m<-matrix(tg_data_s,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
testing_data_m_m<-matrix(testing_data_m,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
testing_data_s_m<-matrix(testing_data_s,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)

tg_data_selected_GI_normalized<-(tg_data_selected_GI-tg_data_m_m)/tg_data_s_m*testing_data_s_m+testing_data_m_m

ccc<-cor(tg_data_selected_GI_normalized,test_training_data0)

colors = c(80:100)/100
my_palette <- colorRampPalette(c("white", "blue"))(n = length(colors)-1)

h<-heatmap.2(ccc,Rowv=F,Colv =F,scale="none",
col=my_palette,breaks=colors,density.info="none",dendrogram="none",trace="none",margin=c(5,5),cexRow=0.4,cexCol=0.4,
key.par=list(mgp=c(5, 0.5, 0),mar=c(1, 2.5, 1, 1)), lmat=rbind( c(0, 3), c(2,1 ) ,c(0,4)),lhei = c(1,4,0.5))

Rfcms_tg_data_normalized <- CMSclassifier::classifyCMS(tg_data_selected_GI_normalized,method="RF")[[3]]
sum(Rfcms_testing_data[,5]==Rfcms_tg_data[,5])
sum(Rfcms_testing_data[,5]==Rfcms_tg_data_normalized[,5])
sum(Rfcms_testing_data[,5]!=Rfcms_tg_data[,5])
sum(Rfcms_testing_data[,5]!=Rfcms_tg_data_normalized[,5])

par(mfcol=c(1,2))
boxplot(apply(Rfcms_tg_data_normalized[,1:4],1,max)~Rfcms_tg_data_normalized[,5]==Rfcms_testing_data[,5],main="New_Normalized\ndata_prediction")
boxplot(apply(Rfcms_testing_data[,1:4],1,max)~Rfcms_tg_data_normalized[,5]==Rfcms_testing_data[,5],main="Original_data\nprediction")

#################################################
list.files("C:/chizhang/2016_Nov_Sen_Liang_QB_CRC/CRC-GSE-DATA")

load("C:/chizhang/2016_Nov_Sen_Liang_QB_CRC/CRC-GSE-DATA/GSE37892_GPL570_RMA_normalized_step2.probe.nomap.RData")
tg_samples<-colnames(d.matrix)
tg_samples0<-intersect(tg_samples,rownames(sampleData))
test_training_data<-t(as.matrix(sampleData[tg_samples0,]))
test_training_data0<-test_training_data[tg_genes_570_GI,]
dim(test_training_data0)
tg_data<-d.matrix[,tg_samples0]

tg_genes_570_GI_info_cdata<-cbind(tg_genes_570_GI_info,tg_genes_570_GI_info)
tg_genes_570_GI_info_cdata[,3]<-""
tg_genes_570_GI_info_cdata[,4]<-""
colnames(tg_genes_570_GI_info_cdata)<-c("Symbol","GI","tg_probe","Total_N_probe")
tg_data_m<-apply(tg_data,1,median)
for(i in 1:nrow(tg_genes_570_GI_info_cdata))
{
	tg_gene_c<-tg_genes_570_GI_info_cdata[i,1]
	tg_probe_ids<-GPL570_id_symbol[which(GPL570_id_symbol[,2]==tg_gene_c),1]
	if(length(tg_probe_ids)==1)
	{
		tg_genes_570_GI_info_cdata[i,3]<-tg_probe_ids
		tg_genes_570_GI_info_cdata[i,4]<-1
	}
	else
	{
		tg_genes_570_GI_info_cdata[i,3]<-tg_probe_ids[which(tg_data_m[tg_probe_ids]==max(tg_data_m[tg_probe_ids]))][1]
		tg_genes_570_GI_info_cdata[i,4]<-length(tg_probe_ids)
	}
}

GPL570_id_symbol0<-GPL570_id_symbol
rownames(GPL570_id_symbol0)<-GPL570_id_symbol[,1]
sum(tg_genes_570_GI_info_cdata[,1]==GPL570_id_symbol0[tg_genes_570_GI_info_cdata[,3],2])
dim(tg_genes_570_GI_info_cdata)
tg_data_selected_GI<-tg_data[tg_genes_570_GI_info_cdata[,3],]
rownames(tg_data_selected_GI)<-tg_genes_570_GI_info_cdata[,2]

dim(test_training_data0)
dim(tg_data_selected_GI)
sum(rownames(tg_data_selected_GI)==rownames(test_training_data0))
sum(colnames(tg_data_selected_GI)==colnames(test_training_data0))

ccc<-cor(tg_data_selected_GI,test_training_data0)

library(gplots)
colors = c(-100:100)/100
my_palette <- colorRampPalette(c("red", "white", "blue"))(n = length(colors)-1)

colors = c(80:100)/100
my_palette <- colorRampPalette(c("white", "blue"))(n = length(colors)-1)

h<-heatmap.2(ccc,Rowv=F,Colv =F,scale="none",
col=my_palette,breaks=colors,density.info="none",dendrogram="none",trace="none",margin=c(5,5),cexRow=0.4,cexCol=0.4,
key.par=list(mgp=c(5, 0.5, 0),mar=c(1, 2.5, 1, 1)), lmat=rbind( c(0, 3), c(2,1 ) ,c(0,4)),lhei = c(1,4,0.5))

###################################

Rfcms_tg_data <- CMSclassifier::classifyCMS(tg_data_selected_GI,method="RF")[[3]]
Rfcms_testing_data <- CMSclassifier::classifyCMS(test_training_data0,method="RF")[[3]]
Rfcms_testing_data[,5]==Rfcms_tg_data[,5]

tg_data_m<-apply(tg_data_selected_GI,1,mean)
tg_data_s<-apply(tg_data_selected_GI,1,sd)
testing_data_m<-apply(test_training_data0,1,mean)
testing_data_s<-apply(test_training_data0,1,sd)

tg_data_m_m<-matrix(tg_data_m,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
tg_data_s_m<-matrix(tg_data_s,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
testing_data_m_m<-matrix(testing_data_m,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
testing_data_s_m<-matrix(testing_data_s,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)

tg_data_selected_GI_normalized<-(tg_data_selected_GI-tg_data_m_m)/tg_data_s_m*testing_data_s_m+testing_data_m_m

ccc<-cor(tg_data_selected_GI_normalized,test_training_data0)

colors = c(80:100)/100
my_palette <- colorRampPalette(c("white", "blue"))(n = length(colors)-1)

h<-heatmap.2(ccc,Rowv=F,Colv =F,scale="none",
col=my_palette,breaks=colors,density.info="none",dendrogram="none",trace="none",margin=c(5,5),cexRow=0.4,cexCol=0.4,
key.par=list(mgp=c(5, 0.5, 0),mar=c(1, 2.5, 1, 1)), lmat=rbind( c(0, 3), c(2,1 ) ,c(0,4)),lhei = c(1,4,0.5))

Rfcms_tg_data_normalized <- CMSclassifier::classifyCMS(tg_data_selected_GI_normalized,method="RF")[[3]]
sum(Rfcms_testing_data[,5]==Rfcms_tg_data[,5])
sum(Rfcms_testing_data[,5]==Rfcms_tg_data_normalized[,5])
sum(Rfcms_testing_data[,5]!=Rfcms_tg_data[,5])
sum(Rfcms_testing_data[,5]!=Rfcms_tg_data_normalized[,5])

par(mfcol=c(1,2))
boxplot(apply(Rfcms_tg_data_normalized[,1:4],1,max)~Rfcms_tg_data_normalized[,5]==Rfcms_testing_data[,5],main="New_Normalized\ndata_prediction")
boxplot(apply(Rfcms_testing_data[,1:4],1,max)~Rfcms_tg_data_normalized[,5]==Rfcms_testing_data[,5],main="Original_data\nprediction")

##########################
#################################################
list.files("C:/chizhang/2016_Nov_Sen_Liang_QB_CRC/CRC-GSE-DATA")

load("C:/chizhang/2016_Nov_Sen_Liang_QB_CRC/CRC-GSE-DATA/GSE39582_GPL570_noRMA_step2.probe.nomap.RData")
tg_samples<-colnames(d.matrix)
tg_samples0<-intersect(tg_samples,rownames(sampleData))
test_training_data<-t(as.matrix(sampleData[tg_samples0,]))
test_training_data0<-test_training_data[tg_genes_570_GI,]
dim(test_training_data0)
tg_data<-d.matrix[,tg_samples0]

tg_genes_570_GI_info_cdata<-cbind(tg_genes_570_GI_info,tg_genes_570_GI_info)
tg_genes_570_GI_info_cdata[,3]<-""
tg_genes_570_GI_info_cdata[,4]<-""
colnames(tg_genes_570_GI_info_cdata)<-c("Symbol","GI","tg_probe","Total_N_probe")
tg_data_m<-apply(tg_data,1,median)
for(i in 1:nrow(tg_genes_570_GI_info_cdata))
{
	tg_gene_c<-tg_genes_570_GI_info_cdata[i,1]
	tg_probe_ids<-GPL570_id_symbol[which(GPL570_id_symbol[,2]==tg_gene_c),1]
	if(length(tg_probe_ids)==1)
	{
		tg_genes_570_GI_info_cdata[i,3]<-tg_probe_ids
		tg_genes_570_GI_info_cdata[i,4]<-1
	}
	else
	{
		tg_genes_570_GI_info_cdata[i,3]<-tg_probe_ids[which(tg_data_m[tg_probe_ids]==max(tg_data_m[tg_probe_ids]))][1]
		tg_genes_570_GI_info_cdata[i,4]<-length(tg_probe_ids)
	}
}

GPL570_id_symbol0<-GPL570_id_symbol
rownames(GPL570_id_symbol0)<-GPL570_id_symbol[,1]
sum(tg_genes_570_GI_info_cdata[,1]==GPL570_id_symbol0[tg_genes_570_GI_info_cdata[,3],2])
dim(tg_genes_570_GI_info_cdata)
tg_data_selected_GI<-tg_data[tg_genes_570_GI_info_cdata[,3],]
rownames(tg_data_selected_GI)<-tg_genes_570_GI_info_cdata[,2]

dim(test_training_data0)
dim(tg_data_selected_GI)
sum(rownames(tg_data_selected_GI)==rownames(test_training_data0))
sum(colnames(tg_data_selected_GI)==colnames(test_training_data0))

ccc<-cor(tg_data_selected_GI,test_training_data0)

library(gplots)
colors = c(-100:100)/100
my_palette <- colorRampPalette(c("red", "white", "blue"))(n = length(colors)-1)

colors = c(80:100)/100
my_palette <- colorRampPalette(c("white", "blue"))(n = length(colors)-1)

h<-heatmap.2(ccc,Rowv=F,Colv =F,scale="none",
col=my_palette,breaks=colors,density.info="none",dendrogram="none",trace="none",margin=c(5,5),cexRow=0.4,cexCol=0.4,
key.par=list(mgp=c(5, 0.5, 0),mar=c(1, 2.5, 1, 1)), lmat=rbind( c(0, 3), c(2,1 ) ,c(0,4)),lhei = c(1,4,0.5))

###################################

Rfcms_tg_data <- CMSclassifier::classifyCMS(tg_data_selected_GI,method="RF")[[3]]
Rfcms_testing_data <- CMSclassifier::classifyCMS(test_training_data0,method="RF")[[3]]
Rfcms_testing_data[,5]==Rfcms_tg_data[,5]

tg_data_m<-apply(tg_data_selected_GI,1,mean)
tg_data_s<-apply(tg_data_selected_GI,1,sd)
testing_data_m<-apply(test_training_data0,1,mean)
testing_data_s<-apply(test_training_data0,1,sd)

tg_data_m_m<-matrix(tg_data_m,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
tg_data_s_m<-matrix(tg_data_s,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
testing_data_m_m<-matrix(testing_data_m,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)
testing_data_s_m<-matrix(testing_data_s,nrow(tg_data_selected_GI),ncol(tg_data_selected_GI),byrow=F)

tg_data_selected_GI_normalized<-(tg_data_selected_GI-tg_data_m_m)/tg_data_s_m*testing_data_s_m+testing_data_m_m

ccc<-cor(tg_data_selected_GI_normalized,test_training_data0)

colors = c(80:100)/100
my_palette <- colorRampPalette(c("white", "blue"))(n = length(colors)-1)

h<-heatmap.2(ccc,Rowv=F,Colv =F,scale="none",
col=my_palette,breaks=colors,density.info="none",dendrogram="none",trace="none",margin=c(5,5),cexRow=0.4,cexCol=0.4,
key.par=list(mgp=c(5, 0.5, 0),mar=c(1, 2.5, 1, 1)), lmat=rbind( c(0, 3), c(2,1 ) ,c(0,4)),lhei = c(1,4,0.5))

Rfcms_tg_data_normalized <- CMSclassifier::classifyCMS(tg_data_selected_GI_normalized,method="RF")[[3]]
sum(Rfcms_testing_data[,5]==Rfcms_tg_data[,5])
sum(Rfcms_testing_data[,5]==Rfcms_tg_data_normalized[,5])
sum(Rfcms_testing_data[,5]!=Rfcms_tg_data[,5])
sum(Rfcms_testing_data[,5]!=Rfcms_tg_data_normalized[,5])

par(mfcol=c(1,2))
boxplot(apply(Rfcms_tg_data_normalized[,1:4],1,max)~Rfcms_tg_data_normalized[,5]==Rfcms_testing_data[,5],main="New_Normalized\ndata_prediction")
boxplot(apply(Rfcms_testing_data[,1:4],1,max)~Rfcms_tg_data_normalized[,5]==Rfcms_testing_data[,5],main="Original_data\nprediction")

##########################
GSE2109
GSE37892
GSE39582
TCGA
