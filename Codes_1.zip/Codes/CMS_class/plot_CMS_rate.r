
CMS_rate_all_GEO<-c()
CMS_sample_list_all_GEO<-list()
names_all<-c()
for(i in c(1,2,4:8))
{
	ccc<-CMS_prediction_GPL570RMA[[i]]
	s1<-rownames(ccc)[which(ccc[,1]>0.4)]
	s2<-rownames(ccc)[which(ccc[,2]>0.4)]
	s3<-rownames(ccc)[which(ccc[,3]>0.4)]
	s4<-rownames(ccc)[which(ccc[,4]>0.4)]
	s5<-names(which(table(c(s1,s2,s3,s4))>1))
	s6<-setdiff(rownames(ccc),unique(c(s1,s2,s3,s4)))
	s10<-setdiff(s1,s5)
	s20<-setdiff(s2,s5)
	s30<-setdiff(s3,s5)
	s40<-setdiff(s4,s5)
	ddd<-c(length(s10),length(s20),length(s30),length(s40),length(s5),length(s6))
	ddd<-ddd/sum(ddd)
	ll_c<-list(s10,s20,s30,s40,s5,s6)
	names(ll_c)<-c("CMS1","CMS2","CMS3","CMS4","CMS5","CMS6")
	CMS_sample_list_all_GEO[[i]]<-ll_c
	CMS_rate_all_GEO<-rbind(CMS_rate_all_GEO,ddd)
	names_c<-unlist(strsplit(names(CMS_prediction_GPL570RMA)[i],"_"))[2]
	names_all<-c(names_all,names_c)
}
colnames(CMS_rate_all_GEO)<-c("CMS1","CMS2","CMS3","CMS4","CMS5","CMS6")
rownames(CMS_rate_all_GEO)<-names_all
names(CMS_sample_list_all_GEO)<-names_all

ccc<-CMS_prediction_TCGA
s1<-rownames(ccc)[which(ccc[,1]>0.4)]
s2<-rownames(ccc)[which(ccc[,2]>0.4)]
s3<-rownames(ccc)[which(ccc[,3]>0.4)]
s4<-rownames(ccc)[which(ccc[,4]>0.4)]
s5<-names(which(table(c(s1,s2,s3,s4))>1))
s6<-setdiff(rownames(ccc),unique(c(s1,s2,s3,s4)))
s10<-setdiff(s1,s5)
s20<-setdiff(s2,s5)
s30<-setdiff(s3,s5)
s40<-setdiff(s4,s5)
ddd<-c(length(s10),length(s20),length(s30),length(s40),length(s5),length(s6))
ddd<-ddd/sum(ddd)
ll_c<-list(s10,s20,s30,s40,s5,s6)
names(ll_c)<-c("CMS1","CMS2","CMS3","CMS4","CMS5","CMS6")
i<-8
CMS_sample_list_all_GEO[[i]]<-ll_c
CMS_rate_all_GEO<-rbind(CMS_rate_all_GEO,ddd)
names_c<-"TCGA_COAD"
names_all<-c(names_all,names_c)
colnames(CMS_rate_all_GEO)<-c("CMS1","CMS2","CMS3","CMS4","CMS5","CMS6")
rownames(CMS_rate_all_GEO)<-names_all
names(CMS_sample_list_all_GEO)<-names_all

pdf("CMS_rate2.pdf")
par(xpd=T, mar=par()$mar+c(2,0,0,5))

barplot(t(CMS_rate_all_GEO),
col=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue"),las=2, yaxt="n")

library(scales)
dates <-  1:100
returns <- runif(100)
yticks_val <- pretty_breaks(n=5)(returns)
axis(2, at=yticks_val, lab=percent(yticks_val))

legend(10, 1, c(colnames(CMS_rate_all_GEO)[1:4],"None","Multi-CMS"), fill=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue"));
dev.off()

save(list="CMS_sample_list_all_GEO",file="CMS_sample_list_all.RData")


