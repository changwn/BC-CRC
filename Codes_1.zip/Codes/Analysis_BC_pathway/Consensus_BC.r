i<-1
j<-1
k<-1



tg_list_all<-list()
for(i in 1:length(sig_BC_list_all))
{
	tg_list_c<-list()
	N<-0
	names_c<-c()
	for(j in 1:length(sig_BC_list_all[[i]]))
	{
		for(k in 1:length(sig_BC_list_all[[i]][[j]]))
		{	
			N<-N+1
			tg_list_c[[N]]<-sig_BC_list_all[[i]][[j]][[k]][[3]]
		}
		names_c<-c(names_c,names(sig_BC_list_all[[i]][[j]]))
	}
	tg_list_all[[i]]<-tg_list_c
	names(tg_list_all[[i]])<-names_c
}
names(tg_list_all)<-names(sig_BC_list_all)

tg_list_all_length<-list()
for(i in 1:length(tg_list_all))
{
	aaa<-unlist(lapply(tg_list_all[[i]],length))
	tg_list_all_length[[i]]<-aaa
	names(tg_list_all_length[[i]])<-names(tg_list_all[[i]])
}
names(tg_list_all_length)<-names(tg_list_all)

save(list=c("tg_list_all_length","tg_list_all"),file="Merged_BC_genes_all_data.RData")



i<-1
j<-2

Jaccard<-function(aaa,bbb)
{
	return(length(intersect(aaa,bbb))/length(unique(c(aaa,bbb))))
}
Jaccard(tg_list_1[[1]],tg_list_2[[1]])


aaa<-mapply(function(X,Y) {Jaccard(X,Y)},X=tg_list_1,Y=tg_list_2[[1]])
ccc_c<-c()

for(ii in 1:length(tg_list_all))
{
	for(jj in 1:length(tg_list_all))
	{
if(ii<=jj)
{
tg_list_1<-tg_list_all[[ii]]
tg_list_2<-tg_list_all[[jj]]
tg_R<-paste("Jaccard_new_",ii,"_",jj,".RData",sep="")
ccc_c<-c()
for(i in 1:length(tg_list_1))
{
	bbb<-rep(0,length(tg_list_2))
	for(j in 1:length(tg_list_2))
	{
		bbb[j]<-Jaccard(tg_list_1[[i]],tg_list_2[[j]])
	}
	ccc_c<-cbind(ccc_c,bbb)
	if(i%%500==1)
	{
		print(i)
	}
}
Jaccard_c<-ccc_c
save(list=c("Jaccard_c"),file=tg_R)
rm(ccc_c)
rm(Jaccard_c)
print(c(ii,jj))
}
	}	
}

listA <- list(matrix(rnorm(2000), nrow=10),
              matrix(rnorm(2000), nrow=10))
listB <- list(matrix(rnorm(2000), nrow=10),
              matrix(rnorm(2000), nrow=10))
mapply(function(X,Y) {
  sapply(1:10, function(row) cor(X[row,], Y[row,]))
  }, X=listA, Y=listB)

################################


tg_list_all_new_F_0.85<-list()
for(i in 1:length(sig_BC_list_all_new_F_0.85))
{
	tg_list_c<-list()
	N<-0
	for(j in 1:length(sig_BC_list_all_new_F_0.85[[i]]))
	{
		for(k in 1:length(sig_BC_list_all_new_F_0.85[[i]][[j]]))
		{	
			N<-N+1
			tg_list_c[[N]]<-sig_BC_list_all_new_F_0.85[[i]][[j]][[k]][[3]]
		}
	}
	tg_list_all_new_F_0.85[[i]]<-tg_list_c
}
names(tg_list_all_new_F_0.85)<-names(sig_BC_list_all_new_F_0.85)



for(ii in 1:length(tg_list_all_new_F_0.85))
{
	for(jj in 1:length(tg_list_all_new_F_0.85))
	{
if(ii<=jj)
{
tg_list_1<-tg_list_all_new_F_0.85[[ii]]
tg_list_2<-tg_list_all_new_F_0.85[[jj]]
tg_R<-paste("Jaccard_new_F_0.85_",ii,"_",jj,".RData",sep="")
ccc_c<-c()
for(i in 1:length(tg_list_1))
{
	bbb<-rep(0,length(tg_list_2))
	for(j in 1:length(tg_list_2))
	{
		bbb[j]<-Jaccard(tg_list_1[[i]],tg_list_2[[j]])
	}
	ccc_c<-cbind(ccc_c,bbb)
	if(i%%500==1)
	{
		print(i)
	}
}
Jaccard_c<-ccc_c
save(list=c("Jaccard_c"),file=tg_R)
rm(ccc_c)
rm(Jaccard_c)
print(c(ii,jj))
}
	}	
}

