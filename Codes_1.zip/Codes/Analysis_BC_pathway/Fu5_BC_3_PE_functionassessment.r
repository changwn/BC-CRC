TCGA_PE_all_list[[names(BC_info_c_all)[tg_ids[i]]]]

BC23
BC679

FU5_tg_BCs_new2_all


names(TCGA_PE_all_list[["TCGA_COAD_FPKM_T_RMA_MAP_filter_O_3000_F_0.25_C_0.9_BC_23"]])
tg_BCs_info_extracted[["TCGA_COAD_FPKM_T_RMA_MAP_filter_O_3000_F_0.25_C_0.9_BC_23"]][[3]]
tg_BCs_info_extracted[["TCGA_COAD_FPKM_T_RMA_MAP_filter_O_3000_F_0.25_C_0.9_BC_23"]][[4]]

rownames(TCGA_ensem_annotation0)<-TCGA_ensem_annotation0[,7]

aaa<-sort(unique(as.character(TCGA_ensem_annotation0[tg_BCs_info_extracted[["TCGA_COAD_FPKM_T_RMA_MAP_filter_O_3000_F_0.25_C_0.9_BC_23"]][[4]],4])))
rownames(TCGA_ensem_annotation)<-TCGA_ensem_annotation[,4]
bbb<-TCGA_ensem_annotation[aaa[-1],]
bbb[which(bbb[,3]!="processed_pseudogene"),]


DEXI