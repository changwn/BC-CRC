

###################################
mean(dfs_stat[,7])
mean(os_stat[,7])

mean(dfs_stat[,4])
mean(os_stat[,4])

mean(dfs_stat[,1])/0.429
mean(os_stat[,1])/0.429
mean(dfs_stat[,2])/0.429
mean(os_stat[,2])/.429

22.8/42.9
20.0/49.5


###################################
key<-"dfs_in_2"
p_cut<-0.05

N<-0
PE_top_rate<-list()
cnames<-c()
for(tg_id in 1:length(names_index))
{	
	i<-names_index[tg_id]
	if(sum(colnames(clinical_sig[[i]])==key)>0)
	{
		print(i)
		print(names(which(clinical_sig[[i]][,key]<p_cut)))
		tg_eee<-names(which(clinical_sig[[i]][,key]<p_cut))
		PE_all_c<-c()
		if(length(tg_eee)>0)
		{
			print(length(tg_eee))
			aaa<-c()
			for(j in 1:length(tg_eee))
			{
				aaa<-c(aaa,names(PE_all_list_all[[tg_eee[j]]]))
			}
			N<-N+1
			PE_top_rate[[N]]<-sort(table(aaa))/length(tg_eee)
			cnames<-c(cnames,names(names_index)[tg_id])
		}
	}
}
names(PE_top_rate)<-cnames

ccc<-matrix(0,length(pathway_all_2015_Jan),length(PE_top_rate))
rownames(ccc)<-names(pathway_all_2015_Jan)
colnames(ccc)<-names(PE_top_rate)
for(i in 1:length(PE_top_rate))
{
	for(j in 1:length(PE_top_rate[[i]]))
	{
		ccc[names(PE_top_rate[[i]])[j],i]<-PE_top_rate[[i]][j]
	}
}
ccc[names(sort(apply(ccc[,-1],1,mean),decreasing=T)[1:100]),]




key<-"dfs_in_4"
p_cut<-0.05

N<-0
PE_top_rate<-list()
cnames<-c()
for(tg_id in 1:length(names_index))
{	
	i<-names_index[tg_id]
	if(sum(colnames(clinical_sig[[i]])==key)>0)
	{
		print(i)
		print(names(which(clinical_sig[[i]][,key]<p_cut)))
		tg_eee<-names(which(clinical_sig[[i]][,key]<p_cut))
		PE_all_c<-c()
		if(length(tg_eee)>0)
		{
			print(length(tg_eee))
			aaa<-c()
			for(j in 1:length(tg_eee))
			{
				aaa<-c(aaa,names(PE_all_list_all[[tg_eee[j]]]))
			}
			N<-N+1
			PE_top_rate[[N]]<-sort(table(aaa))/length(tg_eee)
			cnames<-c(cnames,names(names_index)[tg_id])
		}
	}
}
names(PE_top_rate)<-cnames

ccc<-matrix(0,length(pathway_all_2015_Jan),length(PE_top_rate))
rownames(ccc)<-names(pathway_all_2015_Jan)
colnames(ccc)<-names(PE_top_rate)
for(i in 1:length(PE_top_rate))
{
	for(j in 1:length(PE_top_rate[[i]]))
	{
		ccc[names(PE_top_rate[[i]])[j],i]<-PE_top_rate[[i]][j]
	}
}
ccc[names(sort(apply(ccc[,-1],1,mean),decreasing=T)[1:100]),]




key<-"dfs_in_1"
p_cut<-0.05

N<-0
PE_top_rate<-list()
cnames<-c()
for(tg_id in 1:length(names_index))
{	
	i<-names_index[tg_id]
	if(sum(colnames(clinical_sig[[i]])==key)>0)
	{
		print(i)
		print(names(which(clinical_sig[[i]][,key]<p_cut)))
		tg_eee<-names(which(clinical_sig[[i]][,key]<p_cut))
		PE_all_c<-c()
		if(length(tg_eee)>0)
		{
			print(length(tg_eee))
			aaa<-c()
			for(j in 1:length(tg_eee))
			{
				aaa<-c(aaa,names(PE_all_list_all[[tg_eee[j]]]))
			}
			N<-N+1
			PE_top_rate[[N]]<-sort(table(aaa))/length(tg_eee)
			cnames<-c(cnames,names(names_index)[tg_id])
		}
	}
}
names(PE_top_rate)<-cnames

ccc<-matrix(0,length(pathway_all_2015_Jan),length(PE_top_rate))
rownames(ccc)<-names(pathway_all_2015_Jan)
colnames(ccc)<-names(PE_top_rate)
for(i in 1:length(PE_top_rate))
{
	for(j in 1:length(PE_top_rate[[i]]))
	{
		ccc[names(PE_top_rate[[i]])[j],i]<-PE_top_rate[[i]][j]
	}
}
ccc[names(sort(apply(ccc,1,mean),decreasing=T)[1:100]),]



key<-"os_in_1"
p_cut<-0.05

N<-0
PE_top_rate<-list()
cnames<-c()
for(tg_id in 1:length(names_index))
{	
	i<-names_index[tg_id]
	if(sum(colnames(clinical_sig[[i]])==key)>0)
	{
		print(i)
		print(names(which(clinical_sig[[i]][,key]<p_cut)))
		tg_eee<-names(which(clinical_sig[[i]][,key]<p_cut))
		PE_all_c<-c()
		if(length(tg_eee)>0)
		{
			print(length(tg_eee))
			aaa<-c()
			for(j in 1:length(tg_eee))
			{
				aaa<-c(aaa,names(PE_all_list_all[[tg_eee[j]]]))
			}
			N<-N+1
			PE_top_rate[[N]]<-sort(table(aaa))/length(tg_eee)
			cnames<-c(cnames,names(names_index)[tg_id])
		}
	}
}
names(PE_top_rate)<-cnames

ccc<-matrix(0,length(pathway_all_2015_Jan),length(PE_top_rate))
rownames(ccc)<-names(pathway_all_2015_Jan)
colnames(ccc)<-names(PE_top_rate)
for(i in 1:length(PE_top_rate))
{
	for(j in 1:length(PE_top_rate[[i]]))
	{
		ccc[names(PE_top_rate[[i]])[j],i]<-PE_top_rate[[i]][j]
	}
}
ccc[names(sort(apply(ccc[,-3],1,mean),decreasing=T)[1:100]),]


key<-"os_in_2"
p_cut<-0.05

N<-0
PE_top_rate<-list()
cnames<-c()
for(tg_id in 1:length(names_index))
{	
	i<-names_index[tg_id]
	if(sum(colnames(clinical_sig[[i]])==key)>0)
	{
		print(i)
		print(names(which(clinical_sig[[i]][,key]<p_cut)))
		tg_eee<-names(which(clinical_sig[[i]][,key]<p_cut))
		PE_all_c<-c()
		if(length(tg_eee)>0)
		{
			print(length(tg_eee))
			aaa<-c()
			for(j in 1:length(tg_eee))
			{
				aaa<-c(aaa,names(PE_all_list_all[[tg_eee[j]]]))
			}
			N<-N+1
			PE_top_rate[[N]]<-sort(table(aaa))/length(tg_eee)
			cnames<-c(cnames,names(names_index)[tg_id])
		}
	}
}
names(PE_top_rate)<-cnames

ccc<-matrix(0,length(pathway_all_2015_Jan),length(PE_top_rate))
rownames(ccc)<-names(pathway_all_2015_Jan)
colnames(ccc)<-names(PE_top_rate)
for(i in 1:length(PE_top_rate))
{
	for(j in 1:length(PE_top_rate[[i]]))
	{
		ccc[names(PE_top_rate[[i]])[j],i]<-PE_top_rate[[i]][j]
	}
}
ccc[names(sort(apply(ccc[,-1],1,mean),decreasing=T)[1:100]),]



key<-"os_in_4"
p_cut<-0.05

N<-0
PE_top_rate<-list()
cnames<-c()
for(tg_id in 1:length(names_index))
{	
	i<-names_index[tg_id]
	if(sum(colnames(clinical_sig[[i]])==key)>0)
	{
		print(i)
		print(names(which(clinical_sig[[i]][,key]<p_cut)))
		tg_eee<-names(which(clinical_sig[[i]][,key]<p_cut))
		PE_all_c<-c()
		if(length(tg_eee)>0)
		{
			print(length(tg_eee))
			aaa<-c()
			for(j in 1:length(tg_eee))
			{
				aaa<-c(aaa,names(PE_all_list_all[[tg_eee[j]]]))
			}
			N<-N+1
			PE_top_rate[[N]]<-sort(table(aaa))/length(tg_eee)
			cnames<-c(cnames,names(names_index)[tg_id])
		}
	}
}
names(PE_top_rate)<-cnames

ccc<-matrix(0,length(pathway_all_2015_Jan),length(PE_top_rate))
rownames(ccc)<-names(pathway_all_2015_Jan)
colnames(ccc)<-names(PE_top_rate)
for(i in 1:length(PE_top_rate))
{
	for(j in 1:length(PE_top_rate[[i]]))
	{
		ccc[names(PE_top_rate[[i]])[j],i]<-PE_top_rate[[i]][j]
	}
}
ccc[names(sort(apply(ccc[,-1],1,mean),decreasing=T)[1:100]),]\


