CMS_sample_list_all_GEO
load("CMS_sample_list_all.RData")
load("GEO_tg_list_samples_all.RData")
load("TCGA_tg_list_samples_all.RData")

pdf("Overlap_Rate_CMS_specific_BCs_BC.pdf")
par(mfcol=c(2,4))
for(i in c(1:7))
{
	tg_i<-names(CMS_BC_enrich_list)[i]
	tg_ic<-names_index[tg_i]
	ccc<-CMS_BC_enrich_list[[i]]
	ccc0<-sig_BC_pp_all[[tg_ic]]
	ccc1<-CMS_sample_list_all_GEO[[tg_i]]
	ccc2<-tg_list_samples_all[[tg_ic]]
	fff<-c()
	for(j in 1:4)
	{
		tg_ccc<-ccc[[j]]
		tg_sall<-ccc1[[j]]
		eee<-c()
		for(k in 1:length(tg_ccc))
		{
			tg_s1<-ccc2[[tg_ccc[k]]]
			eee<-c(eee,length(intersect(tg_s1,tg_sall))/length(tg_s1))
		}
		fff[[j]]<-eee
	}
	names(fff)<-c("CMS1","CMS2","CMS3","CMS4")
	boxplot(fff,col=c("lightblue","lightgoldenrod1","palegreen","indianred1"),pch=16,las=2, yaxt="n",main=tg_i)
	
	library(scales)
	dates <-  1:100
	returns <- runif(100)
	yticks_val <- pretty_breaks(n=5)(returns)
	axis(2, at=yticks_val, lab=percent(yticks_val))
}

i<-8
tg_i<-names(CMS_BC_enrich_list)[i]
tg_ic<-names_index[tg_i]
ccc<-CMS_BC_enrich_list[[i]]
ccc0<-sig_BC_pp_all[[tg_ic]]
ccc1<-CMS_sample_list_all_GEO[[tg_i]]
ccc2<-TCGA_tg_list_samples_all[[1]]
fff<-c()
for(j in 1:4)
{
  tg_ccc<-ccc[[j]]
  tg_sall<-ccc1[[j]]
  eee<-c()
  for(k in 1:length(tg_ccc))
  {
    tg_s1<-ccc2[[tg_ccc[k]]]
    tg_s1<-edit_colnames(tg_s1)
    eee<-c(eee,length(intersect(tg_s1,tg_sall))/length(tg_s1))
  }
  fff[[j]]<-eee
}
names(fff)<-c("CMS1","CMS2","CMS3","CMS4")
boxplot(fff,col=c("lightblue","lightgoldenrod1","palegreen","indianred1"),pch=16,las=2, yaxt="n",main=tg_i)

library(scales)
dates <-  1:100
returns <- runif(100)
yticks_val <- pretty_breaks(n=5)(returns)
axis(2, at=yticks_val, lab=percent(yticks_val))
dev.off()



pdf("Overlap_Rate_CMS_specific_BCs_CMS.pdf")
par(mfcol=c(2,4))
ggg<-list()
for(i in c(1:7))
{
  tg_i<-names(CMS_BC_enrich_list)[i]
  tg_ic<-names_index[tg_i]
  ccc<-CMS_BC_enrich_list[[i]]
  ccc0<-sig_BC_pp_all[[tg_ic]]
  ccc1<-CMS_sample_list_all_GEO[[tg_i]]
  ccc2<-tg_list_samples_all[[tg_ic]]
  fff<-c()
  for(j in 1:4)
  {
    tg_ccc<-ccc[[j]]
    tg_sall<-ccc1[[j]]
    eee<-c()
    for(k in 1:length(tg_ccc))
    {
      tg_s1<-ccc2[[tg_ccc[k]]]
      eee<-c(eee,length(intersect(tg_s1,tg_sall)))
    }
    eee<-eee/length(tg_sall)
    fff[[j]]<-eee
  }
  names(fff)<-c("CMS1","CMS2","CMS3","CMS4")
  boxplot(fff,col=c("lightblue","lightgoldenrod1","palegreen","indianred1"),pch=16,las=2, yaxt="n",main=tg_i)
  
  library(scales)
  dates <-  1:100
  returns <- runif(100)
  yticks_val <- pretty_breaks(n=5)(returns)
  axis(2, at=yticks_val, lab=percent(yticks_val))
  ggg[[i]]<-fff
}

i<-8
tg_i<-names(CMS_BC_enrich_list)[i]
tg_ic<-names_index[tg_i]
ccc<-CMS_BC_enrich_list[[i]]
ccc0<-sig_BC_pp_all[[tg_ic]]
ccc1<-CMS_sample_list_all_GEO[[tg_i]]
ccc2<-TCGA_tg_list_samples_all[[1]]
fff<-c()
for(j in 1:4)
{
  tg_ccc<-ccc[[j]]
  tg_sall<-ccc1[[j]]
  eee<-c()
  for(k in 1:length(tg_ccc))
  {
    tg_s1<-ccc2[[tg_ccc[k]]]
    tg_s1<-edit_colnames(tg_s1)
    eee<-c(eee,length(intersect(tg_s1,tg_sall)))
  }
  eee<-eee/length(tg_sall)
  fff[[j]]<-eee
}
names(fff)<-c("CMS1","CMS2","CMS3","CMS4")
ggg[[i]]<-fff

boxplot(fff,col=c("lightblue","lightgoldenrod1","palegreen","indianred1"),pch=16,las=2, yaxt="n",main=tg_i)

library(scales)
dates <-  1:100
returns <- runif(100)
yticks_val <- pretty_breaks(n=5)(returns)
axis(2, at=yticks_val, lab=percent(yticks_val))


dev.off()

################################
for(j in 1:4)
{
  ccc<-c()
  for(i in 1:length(ggg))
  {
    ccc<-c(ccc,ggg[[i]][[j]])
  }
  print(mean(ccc))
}

###############################
k<-5
PE_top_rate<-list()
for(i in 1:length(CMS_BC_enrich_list))
{
	tg_eee<-CMS_BC_enrich_list[[i]][[k]]
	aaa<-c()
	for(j in 1:length(tg_eee))
	{
		aaa<-c(aaa,names(PE_all_list_all[[tg_eee[j]]]))
	}
	PE_top_rate[[i]]<-sort(table(aaa))/length(tg_eee)
}
names(PE_top_rate)<-names(BC_sig_allways_stat)
ccc<-matrix(0,length(pathway_all_2015_Jan),length(PE_top_rate))
rownames(ccc)<-names(pathway_all_2015_Jan)
colnames(ccc)<-names(PE_top_rate)
for(i in 1:length(PE_top_rate))
{
	for(j in 1:length(PE_top_rate[[i]]))
	{
		ccc[names(PE_top_rate[[i]])[j],i]<-PE_top_rate[[i]][j]
	}
}
ccc[names(sort(apply(ccc,1,mean),decreasing=T)[1:100]),]



###############################
k<-1
PE_top_rate<-list()
for(i in 1:length(CMS_BC_enrich_list))
{
	tg_eee<-CMS_BC_enrich_list[[i]][[k]]
	aaa<-c()
	for(j in 1:length(tg_eee))
	{
		aaa<-c(aaa,names(PE_all_list_all[[tg_eee[j]]]))
	}
	PE_top_rate[[i]]<-sort(table(aaa))/length(tg_eee)
}
names(PE_top_rate)<-names(BC_sig_allways_stat)
ccc<-matrix(0,length(pathway_all_2015_Jan),length(PE_top_rate))
rownames(ccc)<-names(pathway_all_2015_Jan)
colnames(ccc)<-names(PE_top_rate)
for(i in 1:length(PE_top_rate))
{
	for(j in 1:length(PE_top_rate[[i]]))
	{
		ccc[names(PE_top_rate[[i]])[j],i]<-PE_top_rate[[i]][j]
	}
}
ccc[names(sort(apply(ccc,1,mean),decreasing=T)[1:100]),]

###############################
k<-1
PE_top_rate<-list()
for(i in 1:length(CMS_BC_enrich_list))
{
	tg_eee<-CMS_BC_enrich_list[[i]][[k]]
	aaa<-c()
	for(j in 1:length(tg_eee))
	{
		aaa<-c(aaa,names(PE_all_list_all[[tg_eee[j]]]))
	}
	PE_top_rate[[i]]<-sort(table(aaa))/length(tg_eee)
}
names(PE_top_rate)<-names(BC_sig_allways_stat)
ccc<-matrix(0,length(pathway_all_2015_Jan),length(PE_top_rate))
rownames(ccc)<-names(pathway_all_2015_Jan)
colnames(ccc)<-names(PE_top_rate)
for(i in 1:length(PE_top_rate))
{
	for(j in 1:length(PE_top_rate[[i]]))
	{
		ccc[names(PE_top_rate[[i]])[j],i]<-PE_top_rate[[i]][j]
	}
}
ccc[names(sort(apply(ccc[,-8],1,mean),decreasing=T)[1:100]),]



###############################
k<-1
PE_top_rate<-list()
for(i in 1:length(CMS_BC_enrich_list))
{
	tg_eee<-CMS_BC_enrich_list[[i]][[k]]
	aaa<-c()
	for(j in 1:length(tg_eee))
	{
		aaa<-c(aaa,names(PE_all_list_all[[tg_eee[j]]]))
	}
	PE_top_rate[[i]]<-sort(table(aaa))/length(tg_eee)
}
names(PE_top_rate)<-names(BC_sig_allways_stat)
ccc<-matrix(0,length(pathway_all_2015_Jan),length(PE_top_rate))
rownames(ccc)<-names(pathway_all_2015_Jan)
colnames(ccc)<-names(PE_top_rate)
for(i in 1:length(PE_top_rate))
{
	for(j in 1:length(PE_top_rate[[i]]))
	{
		ccc[names(PE_top_rate[[i]])[j],i]<-PE_top_rate[[i]][j]
	}
}
ccc[names(sort(apply(ccc,1,mean),decreasing=T)[1:150]),]

###############################
k<-5
PE_top_rate<-list()
for(i in 1:length(CMS_BC_enrich_list))
{
	tg_eee<-CMS_BC_enrich_list[[i]][[k]]
	aaa<-c()
	for(j in 1:length(tg_eee))
	{
		aaa<-c(aaa,names(PE_all_list_all[[tg_eee[j]]]))
	}
	PE_top_rate[[i]]<-sort(table(aaa))/length(tg_eee)
}
names(PE_top_rate)<-names(BC_sig_allways_stat)
ccc<-matrix(0,length(pathway_all_2015_Jan),length(PE_top_rate))
rownames(ccc)<-names(pathway_all_2015_Jan)
colnames(ccc)<-names(PE_top_rate)
for(i in 1:length(PE_top_rate))
{
	for(j in 1:length(PE_top_rate[[i]]))
	{
		ccc[names(PE_top_rate[[i]])[j],i]<-PE_top_rate[[i]][j]
	}
}
ccc[names(sort(apply(ccc[,-8],1,mean),decreasing=T)[1:150]),]


