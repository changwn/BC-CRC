
###############################All_PE
tg_pathways<-c("REACTOME_CELL_CYCLE",
"REACTOME_MITOTIC_G2_G2_M_PHASES",
"CHROMATIN_ASSEMBLY",
"MITOCHONDRION",
"ORGAN_DEVELOPMENT",
"REACTOME_HEMOSTASIS",
"RESPONSE_TO_STRESS",
"MEMBRANE_PART",
"KEGG_ADHERENS_JUNCTION",
"REACTOME_INTEGRIN_CELL_SURFACE_INTERACTIONS",
"KEGG_CYTOKINE_CYTOKINE_RECEPTOR_INTERACTION",
"REACTOME_IMMUNE_SYSTEM",
"REACTOME_INNATE_IMMUNE_SYSTEM",
"LEUKOCYTE_MIGRATION")


##################CMS1
tg_pathways1<-c("SPECIFIC_RNA_POLYMERASE_II_TRANSCRIPTION_FACTOR_ACTIVITY",
"UNFOLDED_PROTEIN_RESPONSE",
"KEGG_GLUTATHIONE_METABOLISM",
"WOUND_HEALING",
"CALCIUM_ION_TRANSPORT",
"SA_B_CELL_RECEPTOR_COMPLEXES",
"B_CELL_ACTIVATION",
"REACTOME_INTERFERON_ALPHA_BETA_SIGNALING",
"IMMUNE_EFFECTOR_PROCESS",
"ActivMacrophages",
"REACTOME_HS_GAG_DEGRADATION",
"POSITIVE_REGULATION_OF_PROTEIN_METABOLIC_PROCESS",
"KEGG_WNT_SIGNALING_PATHWAY",
"KEGG_GLYCOLYSIS_GLUCONEOGENESIS",
"REACTOME_CITRIC_ACID_CYCLE_TCA_CYCLE",
"KEGG_CITRATE_CYCLE_TCA_CYCLE",
"KEGG_PYRUVATE_METABOLISM",
"KEGG_GLYCINE_SERINE_AND_THREONINE_METABOLISM"
)

####################################CMS2
tg_pathways2<-c("HORMONE_RECEPTOR_BINDING", 
"NUCLEAR_HORMONE_RECEPTOR_BINDING",
"STEROID_HORMONE_RECEPTOR_SIGNALING_PATHWAY",
"REACTOME_ALPHA_LINOLENIC_ACID_ALA_METABOLISM",
"LIPID_KINASE_ACTIVITY",
"KEGG_PPAR_SIGNALING_PATHWAY",
"PID_P53REGULATIONPATHWAY",
"REACTOME_IL_2_SIGNALING",
"PID_IL2_1PATHWAY",
"CHROMATIN"
)

#############################CMS3 
tg_pathways3<-c(
"INTERLEUKIN_RECEPTOR_ACTIVITY",
"BIOCARTA_CTL_PATHWAY",
"KEGG_CYTOKINE_CYTOKINE_RECEPTOR_INTERACTION",
"REACTOME_GLYCOPROTEIN_HORMONES",
"REACTOME_CELL_EXTRACELLULAR_MATRIX_INTERACTIONS",
"REACTOME_GPCR_DOWNSTREAM_SIGNALING")


#################################CMS4
tg_pathways4<-c("REACTOME_PURINE_SALVAGE",
"CELL_CYCLE_GO_0007049",
"REACTOME_GPCR_DOWNSTREAM_SIGNALING",
"REACTOME_G0_AND_EARLY_G1",
"REACTOME_REPAIR_SYNTHESIS_FOR_GAP_FILLING_BY_DNA_POL_IN_TC_NER",
"SISTER_CHROMATID_SEGREGATION",
"CHROMOSOME_SEGREGATION",
"REGULATION_OF_CYCLIN_DEPENDENT_PROTEIN_KINASE_ACTIVITY",
"Tcell",
"OXIDOREDUCTASE_ACTIVITY",
"KEGG_GLYCOSAMINOGLYCAN_BIOSYNTHESIS_CHONDROITIN_SULFATE",
"Integrin"
)

##############################CMS_U
tg_pathwaysU<-c("PID_RAS_PATHWAY",
"GROWTH_FACTOR_BINDING",
"REACTOME_SIGNALING_BY_NOTCH1",
"PID_MYC_PATHWAY",
"LIPASE_ACTIVITY",
"GROWTH_FACTOR_BINDING",
"KEGG_TGF_BETA_SIGNALING_PATHWAY",
"RECEPTOR_SIGNALING_PROTEIN_ACTIVITY",
"RESPONSE_TO_NUTRIENT_LEVELS","BIOCARTA_BARR_MAPK_PATHWAY")


DFS_OS_pathways<-c(
#DFS
"CHEMOKINE_ACTIVITY",
"CHEMOKINE_RECEPTOR_BINDING",
"G_PROTEIN_COUPLED_RECEPTOR_BINDING",
"OXIDOREDUCTASE_ACTIVITY_ACTING_ON_NADH_OR_NADPH",
"KEGG_O_GLYCAN_BIOSYNTHESIS",
"CYTOKINE_METABOLIC_PROCESS",
"APOPTOSIS_GO",

#DFS1
"MITOCHONDRION",
"OUTER_MEMBRANE",
"ACTIVATION_OF_MAPK_ACTIVITY",
"REGULATION_OF_RESPONSE_TO_STIMULUS",
"REGULATION_OF_IMMUNE_RESPONSE",
"TISSUE_MORPHOGENESIS",

#DFS2
"PID_IL6_7PATHWAY",
"PID_VEGFR1_PATHWAY" ,
"REACTOME_ABCA_TRANSPORTERS_IN_LIPID_HOMEOSTASIS",
"MONOVALENT_INORGANIC_CATION_TRANSMEMBRANE_TRANSPORTER_ACTIVITY",


#DFS3
"INTEGRIN_BINDING",
"interleukin_gene",
"MITOCHONDRION",
"RECEPTOR_ACTIVITY",

#DFS4
"RESPONSE_TO_HORMONE_STIMULUS",
"EXCRETION",
"LIPID_TRANSPORTER_ACTIVITY",
"LIPOPROTEIN_METABOLIC_PROCESS",

#OS
"PROGRAMMED_CELL_DEATH",
"REACTOME_MITOTIC_PROMETAPHASE",
"REGULATION_OF_CELL_PROLIFERATION",
"MITOSIS",
"CELL_CYCLE_GO_0007049",

#OS1
"T_CELL_ACTIVATION",
"ST_WNT_BETA_CATENIN_PATHWAY",
"BIOCARTA_CXCR4_PATHWAY",
"LEUKOCYTE_ACTIVATION",

#OS3
"CYTOKINE_AND_CHEMOKINE_MEDIATED_SIGNALING_PATHWAY",
"KEGG_HEMATOPOIETIC_CELL_LINEAGE",
"EXTRACELLULAR_REGION",
"REACTOME_GLUCOSE_TRANSPORT",

#OS4
"INTEGRIN_BINDING",
"interleukin_gene",
"MITOCHONDRION",
"RECEPTOR_ACTIVITY"
)

##################

tg_pathways0<-c("KEGG_GLYCOLYSIS_GLUCONEOGENESIS",
"REACTOME_CITRIC_ACID_CYCLE_TCA_CYCLE",
"KEGG_CITRATE_CYCLE_TCA_CYCLE",
"KEGG_PYRUVATE_METABOLISM",
"KEGG_GLYCINE_SERINE_AND_THREONINE_METABOLISM" ,
"WOUND_HEALING",
"IMMUNE_RESPONSE",
"UNFOLDED_PROTEIN_RESPONSE",
"WNT_SIGNALING",
"KEGG_WNT_SIGNALING_PATHWAY",
"Tcell",
"ST_TUMOR_NECROSIS_FACTOR_PATHWAY",
"ST_FAS_SIGNALING_PATHWAY",
"REACTOME_SIGNALING_BY_NOTCH1",
"REACTOME_SIGNALING_BY_FGFR_IN_DISEASE",
"REACTOME_SIGNALING_BY_ERBB2",
"REACTOME_SIGNALING_BY_ERBB4",
"REACTOME_PI3K_CASCADE",
"REACTOME_DOUBLE_STRAND_BREAK_REPAIR",
"REACTOME_CELL_CYCLE",
"REACTOME_COLLAGEN_FORMATION",
"RAS_GTPASE_ACTIVATOR_ACTIVITY" ,
"PROGRAMMED_CELL_DEATH",
"PID_MYC_PATHWAY",
"OXIDOREDUCTASE_ACTIVITY",
"NOTCH_SIGNALING_PATHWAY",
"MITOCHONDRION",
"LIPOPROTEIN_BIOSYNTHETIC_PROCESS",
"KEGG_O_GLYCAN_BIOSYNTHESIS",
"KEGG_APOPTOSIS",
"Integrin",
"IMMUNE_RESPONSE",
"CELL_CELL_ADHESION",
"APOPTOSIS_GO",
"ANGIOGENESIS",
"CELL_CYCLE_ARREST_GO_0007050",
"CELL_CYCLE_CHECKPOINT_GO_0000075",
"CELL_CYCLE_GO_0007049",
"REACTOME_IL_2_SIGNALING",
"REACTOME_SIGNALING_BY_WNT",
"REACTOME_SIGNALING_BY_TGF_BETA_RECEPTOR_COMPLEX",
"CELLULAR_LIPID_CATABOLIC_PROCESS",
"DNA_DAMAGE_CHECKPOINT",
"KEGG_GLYCOSAMINOGLYCAN_DEGRADATION",
"LIPASE_ACTIVITY",
"LIPID_CATABOLIC_PROCESS",
"IMMUNE_SYSTEM_PROCESS",
"GROWTH_FACTOR_BINDING",
"HORMONE_RECEPTOR_BINDING",
"KEGG_TGF_BETA_SIGNALING_PATHWAY",
"KEGG_FATTY_ACID_METABOLISM",
"REACTOME_RNA_POL_I_PROMOTER_OPENING",
"B_CELL_ACTIVATION",
"CHROMATIN",
"FATTY_ACID_METABOLIC_PROCESS",
"EXTRACELLULAR_REGION",
"IMMUNE_SYSTEM_PROCESS",
"KEGG_N_GLYCAN_BIOSYNTHESIS",
"KEGG_GLYCOSAMINOGLYCAN_BIOSYNTHESIS_CHONDROITIN_SULFATE",
"OXIDOREDUCTASE_ACTIVITY",
"REACTOME_G1_PHASE")
tg_pathways0<-unique(tg_pathways0)


##################
tg_pathway_final<-c("REACTOME_CELL_CYCLE",
"CHROMATIN_ASSEMBLY",
"MITOCHONDRION",
"REACTOME_HEMOSTASIS",
"KEGG_CYTOKINE_CYTOKINE_RECEPTOR_INTERACTION",
"REACTOME_IMMUNE_SYSTEM",
"SPECIFIC_RNA_POLYMERASE_II_TRANSCRIPTION_FACTOR_ACTIVITY",
"UNFOLDED_PROTEIN_RESPONSE",
"WOUND_HEALING",
"ActivMacrophages",
"B_CELL_ACTIVATION",
"KEGG_WNT_SIGNALING_PATHWAY",
"KEGG_GLYCOLYSIS_GLUCONEOGENESIS",
"REACTOME_CITRIC_ACID_CYCLE_TCA_CYCLE",
"HORMONE_RECEPTOR_BINDING",
"NUCLEAR_HORMONE_RECEPTOR_BINDING",
"PID_P53REGULATIONPATHWAY",
"REACTOME_IL_2_SIGNALING",
"INTERLEUKIN_RECEPTOR_ACTIVITY",
"REACTOME_CELL_EXTRACELLULAR_MATRIX_INTERACTIONS",
"CELL_CYCLE_GO_0007049",
"REGULATION_OF_CYCLIN_DEPENDENT_PROTEIN_KINASE_ACTIVITY",
"Tcell",
"KEGG_GLYCOSAMINOGLYCAN_BIOSYNTHESIS_CHONDROITIN_SULFATE",
"Integrin",
"INTEGRIN_BINDING",
"REACTOME_SIGNALING_BY_NOTCH1",
"PID_MYC_PATHWAY",
"KEGG_TGF_BETA_SIGNALING_PATHWAY",
"CHEMOKINE_RECEPTOR_BINDING",
"KEGG_O_GLYCAN_BIOSYNTHESIS",
"APOPTOSIS_GO",
"OUTER_MEMBRANE",
"ACTIVATION_OF_MAPK_ACTIVITY",
"REGULATION_OF_RESPONSE_TO_STIMULUS",
"TISSUE_MORPHOGENESIS",
"PID_VEGFR1_PATHWAY",
"REACTOME_ABCA_TRANSPORTERS_IN_LIPID_HOMEOSTASIS",
"RECEPTOR_ACTIVITY",
"LIPOPROTEIN_METABOLIC_PROCESS",
"PROGRAMMED_CELL_DEATH",
"REGULATION_OF_CELL_PROLIFERATION",
"MITOSIS",
"T_CELL_ACTIVATION",
"ST_WNT_BETA_CATENIN_PATHWAY",
"LEUKOCYTE_ACTIVATION",
"CYTOKINE_AND_CHEMOKINE_MEDIATED_SIGNALING_PATHWAY",
"EXTRACELLULAR_REGION",
"REACTOME_GLUCOSE_TRANSPORT")


tg_pathway_final_names<-c("cell cycle",
"chromatin assembly",
"mitochondrion",
"hemostasis",
"cytokine/receptor interaction",
"immune system",
"RNA polymerase ii TF activity",
"ER stress",
"wound healing",
"macrophage activation",
"B cell activation",
"WNT signaling",
"glycolysis",
"TCA cycle",
"hormone receptor",
"nuclear factor receptor",
"tp53 pathway",
"il2 signaling",
"interleukin receptor",
"cell ECM interactions",
"cell proliferation",
"CDK activity",
"T cell",
"glycosaminoglycan biosynthesis",
"integrin",
"integrin binding",
"notch signaling",
"MYC signaling",
"TGF-beta signaling",
"chemokine receptor",
"O-linked glycan biosynthesis",
"apoptosis",
"outer membrane",
"activation of MAPK activity",
"response to stimulus",
"tissue morphogenesis",
"VEGFR pathway",
"lipid homeostasis",
"receptor activity",
"lipoprotein metabolism",
"programmed cell death",
"regulation of cell proliferation",
"mitosis",
"T cell activation",
"WNT beta-catenin pathway",
"leukocyte activation",
"cytokine and chemokine signaling",
"extracellular region",
"glucose transport")


#############################
plot_tg_PE_sum(generate_tg_PE_sum(tg_pathways1),"try_CMS1.pdf")
plot_tg_PE_sum(generate_tg_PE_sum(tg_pathways2),"try_CMS2.pdf")
plot_tg_PE_sum(generate_tg_PE_sum(tg_pathways3),"try_CMS3.pdf")
plot_tg_PE_sum(generate_tg_PE_sum(tg_pathways4),"try_CMS4.pdf")
plot_tg_PE_sum(generate_tg_PE_sum(tg_pathways),"try_all_PE.pdf")
plot_tg_PE_sum(generate_tg_PE_sum(tg_pathways0),"try_all_PE0.pdf")


tg_pathways_c<-unique(c(tg_pathways,tg_pathways1,tg_pathways2,tg_pathways3,tg_pathways4,tg_pathwaysU,DFS_OS_pathways))
plot_tg_PE_sum(generate_tg_PE_sum(tg_pathways_c),"try_all6.pdf",left_d=25,cex0=0.2)

tg_PE_sum<-generate_tg_PE_sum(tg_pathway_final)
for(i in 1:length(tg_PE_sum))
{
 names(tg_PE_sum[[i]])<-tg_pathway_final_names
}
plot_tg_PE_sum(tg_PE_sum,"try_final5.pdf",left_d=12,cex0=0.5)


#####################

generate_tg_PE_sum<-function(tg_pathways)
{
tg_PE_sum<-list()
ccc<-c()
N<-0
for(i in 1:length(All_PE_summary))
{
	ccc<-cbind(ccc,All_PE_summary[[i]][[1]])
}
for(i in 1:ncol(ccc))
{
	ccc[,i]<-ccc[,i]/mean(ccc[,i])
}
ccc<-ccc[tg_pathways,]
ccc2<-c()
for(i in 1:length(All_PE_summary))
{
	ccc2<-cbind(ccc2,All_PE_summary[[i]][[2]])
}
ccc2<-ccc2[tg_pathways,]
colnames(ccc)<-names(All_PE_summary)
colnames(ccc2)<-names(All_PE_summary)
Sum_c<-list()
for(i in 1:nrow(ccc))
{
	Sum_c[[i]]<-list(ccc[i,],ccc2[i,])
}
names(Sum_c)<-rownames(ccc)
N<-N+1
tg_PE_sum[[N]]<-Sum_c
tg_ids<-c(1,2,3,4,5)
names(tg_PE_sum)[1]<-"PE"
for(ii in 1:length(tg_ids))
{
	tg_id<-tg_ids[ii]
	ccc<-c()
	for(i in 1:length(CMS_PE_summary))
	{
		ccc<-cbind(ccc,CMS_PE_summary[[i]][[tg_id]][[1]])
	}
	for(i in 1:ncol(ccc))
	{
		ccc[,i]<-ccc[,i]/mean(ccc[,i])
	}
	ccc<-ccc[tg_pathways,]
	ccc2<-c()
	for(i in 1:length(CMS_PE_summary))
	{
		ccc2<-cbind(ccc2,CMS_PE_summary[[i]][[tg_id]][[2]])
	}
	ccc2<-ccc2[tg_pathways,]
	colnames(ccc)<-names(CMS_PE_summary)
	colnames(ccc2)<-names(CMS_PE_summary)
	Sum_c<-list()
	for(i in 1:nrow(ccc))
	{
		Sum_c[[i]]<-list(ccc[i,],ccc2[i,])
	}
	names(Sum_c)<-rownames(ccc)
	N<-N+1
	tg_PE_sum[[N]]<-Sum_c
}
tg_ids2<-c(1,2,3,4,5,6)
for(ii in 1:length(tg_ids2))
{
	tg_id<-tg_ids2[ii]
	ccc<-c()
	for(i in 1:length(DFS_all_PE_summary))
	{
		ccc<-cbind(ccc,DFS_all_PE_summary[[i]][[tg_id]][[1]])
	}
	for(i in 1:ncol(ccc))
	{
		ccc[,i]<-ccc[,i]/mean(ccc[,i])
	}
	ccc<-ccc[tg_pathways,]
	ccc2<-c()
	for(i in 1:length(DFS_all_PE_summary))
	{
		ccc2<-cbind(ccc2,DFS_all_PE_summary[[i]][[tg_id]][[2]])
	}
	ccc2<-ccc2[tg_pathways,]
	colnames(ccc)<-names(DFS_all_PE_summary)
	colnames(ccc2)<-names(DFS_all_PE_summary)
	ccc2<-ccc2[,which(is.na(ccc[1,])==0)]
	ccc<-ccc[,which(is.na(ccc[1,])==0)]	
	Sum_c<-list()
	for(i in 1:nrow(ccc))
	{
		Sum_c[[i]]<-list(ccc[i,],ccc2[i,])
	}
	names(Sum_c)<-rownames(ccc)
	N<-N+1
	tg_PE_sum[[N]]<-Sum_c
}
tg_ids3<-c(1,2,3,4,5,6)
for(ii in 1:length(tg_ids3))
{
	tg_id<-tg_ids3[ii]
	ccc<-c()
	for(i in 1:length(OS_all_PE_summary))
	{
		ccc<-cbind(ccc,OS_all_PE_summary[[i]][[tg_id]][[1]])
	}
	for(i in 1:ncol(ccc))
	{
		ccc[,i]<-ccc[,i]/mean(ccc[,i])
	}
	ccc<-ccc[tg_pathways,]
	ccc2<-c()
	for(i in 1:length(OS_all_PE_summary))
	{
		ccc2<-cbind(ccc2,OS_all_PE_summary[[i]][[tg_id]][[2]])
	}
	ccc2<-ccc2[tg_pathways,]
	colnames(ccc)<-names(OS_all_PE_summary)
	colnames(ccc2)<-names(OS_all_PE_summary)
	ccc2<-ccc2[,which(is.na(ccc[1,])==0)]
	ccc<-ccc[,which(is.na(ccc[1,])==0)]	
	Sum_c<-list()
	for(i in 1:nrow(ccc))
	{
		Sum_c[[i]]<-list(ccc[i,],ccc2[i,])
	}
	names(Sum_c)<-rownames(ccc)
	N<-N+1
	tg_PE_sum[[N]]<-Sum_c
}
names(tg_PE_sum)<-c("PE","CMS1","CMS2","CMS3","CMS4","CMS_UC","DFS","DFS_CMS1","DFS_CMS2","DFS_CMS3","DFS_CMS4","DFS_CMS5","OS","OS_CMS1","OS_CMS2","OS_CMS3","OS_CMS4","OS_CMS5")
return(tg_PE_sum)
}


##########
plot_tg_PE_sum<-function(tg_PE_sum,tg_file,cex0=0.3,cex01=0.3,left_d=15)
{
pdf(tg_file)
library(gplots)
library(circlize)
n <- length(tg_PE_sum[[1]])
m <- length(tg_PE_sum)
rname <- names(tg_PE_sum[[1]])
cname <- names(tg_PE_sum)
   if (is.null(rname))
        rname <- 1:2*n
    if (is.null(cname))
        cname <- 1:2*m
    rname <- as.character(rname)
    cname <- as.character(cname)
par(mar = c(0, 0, 0, 0), bg = "white",lwd=0.02)
plot.new()
plot.window(c(0, 2*m+5), c(0, 2*n+5), asp = 1)
bg0="white"
plot.window(c(-1+ 0.5,2*m + 5.5), c(0, 2*n + 15 ),asp = 1, xlab="", ylab="")
text(-left_d, (n:1)*2-1, rname, cex = cex0)
text((1:m)*2-1, rep(2*n + 4, m), cname, srt = 90,cex = cex01)
color_c<-c("midnightblue",'lightblue','lightgoldenrod1','palegreen','indianred1','mediumpurple1',"midnightblue",'lightblue','lightgoldenrod1','palegreen','indianred1','mediumpurple1',"midnightblue",'lightblue','lightgoldenrod1','palegreen','indianred1','mediumpurple1')
for(k in 1:m)
{
	colors = c(-20:100)/100
	my_palette <- colorRampPalette(c("white", color_c[k]))(n = 121)
	for(j in 1:n)
	{
		c_c<-c((k)*2-1,(n-j+1)*2-1)
		aaa0<-rbind(tg_PE_sum[[k]][[j]][[1]],tg_PE_sum[[k]][[j]][[2]])
		aaa20<-abs(log(aaa0[2,])/log(10))
		aaa20[which(aaa20>4)]<-4
		aaa20<-aaa20/4
		aaa10<-aaa0[1,]
		aaa10[which(aaa10>2)]<-2
		aaa10<-aaa10/2
		aaa<-rbind(aaa10,aaa20)
		aaa<-aaa[,order(-aaa[1,])]
		for(i in 1:ncol(aaa))
		{
			tg_radi<-aaa[1,i]
			col_c<-my_palette[floor(aaa[2,i]*100)+1]
			draw.sector(360/ncol(aaa)*i,360/ncol(aaa)*(i-1),center=c_c,rou1 = tg_radi,col=col_c)
		}
	}
}
dev.off()
}
