tg_pathways<-c("KEGG_GLYCOLYSIS_GLUCONEOGENESIS",
"REACTOME_CITRIC_ACID_CYCLE_TCA_CYCLE",
"KEGG_CITRATE_CYCLE_TCA_CYCLE",
"KEGG_PYRUVATE_METABOLISM",
"KEGG_GLYCINE_SERINE_AND_THREONINE_METABOLISM" ,
"WOUND_HEALING",
"IMMUNE_RESPONSE",
"UNFOLDED_PROTEIN_RESPONSE",
"WNT_SIGNALING",
"KEGG_WNT_SIGNALING_PATHWAY",
"Tcell",
"ST_TUMOR_NECROSIS_FACTOR_PATHWAY",
"ST_FAS_SIGNALING_PATHWAY",
"REACTOME_SIGNALING_BY_NOTCH1",
"REACTOME_SIGNALING_BY_FGFR_IN_DISEASE",
"REACTOME_SIGNALING_BY_ERBB2",
"REACTOME_SIGNALING_BY_ERBB4",
"REACTOME_PI3K_CASCADE",
"REACTOME_DOUBLE_STRAND_BREAK_REPAIR",
"REACTOME_CELL_CYCLE",
"REACTOME_COLLAGEN_FORMATION",
"RAS_GTPASE_ACTIVATOR_ACTIVITY" ,
"PROGRAMMED_CELL_DEATH",
"PID_MYC_PATHWAY",
"OXIDOREDUCTASE_ACTIVITY",
"NOTCH_SIGNALING_PATHWAY",
"MITOCHONDRION",
"LIPOPROTEIN_BIOSYNTHETIC_PROCESS",
"KEGG_O_GLYCAN_BIOSYNTHESIS",
"KEGG_APOPTOSIS",
"Integrin",
"IMMUNE_RESPONSE",
"CELL_CELL_ADHESION",
"APOPTOSIS_GO",
"ANGIOGENESIS",
"CELL_CYCLE_ARREST_GO_0007050",
"CELL_CYCLE_CHECKPOINT_GO_0000075",
"CELL_CYCLE_GO_0007049",
"REACTOME_IL_2_SIGNALING",
"REACTOME_SIGNALING_BY_WNT",
"REACTOME_SIGNALING_BY_TGF_BETA_RECEPTOR_COMPLEX",
"CELLULAR_LIPID_CATABOLIC_PROCESS",
"DNA_DAMAGE_CHECKPOINT",
"KEGG_GLYCOSAMINOGLYCAN_DEGRADATION",
"LIPASE_ACTIVITY",
"LIPID_CATABOLIC_PROCESS",
"IMMUNE_SYSTEM_PROCESS",
"GROWTH_FACTOR_BINDING",
"HORMONE_RECEPTOR_BINDING",
"KEGG_TGF_BETA_SIGNALING_PATHWAY",
"KEGG_FATTY_ACID_METABOLISM",
"REACTOME_RNA_POL_I_PROMOTER_OPENING",
"B_CELL_ACTIVATION",
"CHROMATIN",
"FATTY_ACID_METABOLIC_PROCESS",
"EXTRACELLULAR_REGION",
"IMMUNE_SYSTEM_PROCESS",
"KEGG_N_GLYCAN_BIOSYNTHESIS",
"KEGG_GLYCOSAMINOGLYCAN_BIOSYNTHESIS_CHONDROITIN_SULFATE",
"OXIDOREDUCTASE_ACTIVITY",
"REACTOME_G1_PHASE")
tg_pathways<-unique(tg_pathways)


##################################
tg_ids<-c(1,2,3,4,5)
tg_PE_sum<-list()
for(ii in 1:length(tg_ids))
{
	tg_id<-tg_ids[ii]
	ccc<-c()
	for(i in 1:length(CMS_PE_summary))
	{
		ccc<-cbind(ccc,CMS_PE_summary[[i]][[tg_id]][[1]])
	}
	for(i in 1:ncol(ccc))
	{
		ccc[,i]<-ccc[,i]/mean(ccc[,i])
	}
	ccc<-ccc
	ccc2<-c()
	for(i in 1:length(CMS_PE_summary))
	{
		ccc2<-cbind(ccc2,CMS_PE_summary[[i]][[tg_id]][[2]])
	}
	ccc2<-ccc2
	colnames(ccc)<-names(CMS_PE_summary)
	colnames(ccc2)<-names(CMS_PE_summary)
	Sum_c<-list()
	for(i in 1:nrow(ccc))
	{
		Sum_c[[i]]<-list(ccc[i,],ccc2[i,])
	}
	names(Sum_c)<-rownames(ccc)
	tg_PE_sum[[ii]]<-Sum_c
}
names(tg_PE_sum)<-c("CMS1","CMS2","CMS3","CMS4","CMS_UC")

tg_ids<-c(1,2,3,4,5)
tg_PE_sum<-list()
ddd<-c()
for(ii in 1:length(tg_ids))
{
	tg_id<-tg_ids[ii]
	ccc<-c()
	for(i in 1:length(CMS_PE_summary))
	{
		ccc<-cbind(ccc,CMS_PE_summary[[i]][[tg_id]][[1]])
	}
	for(i in 1:ncol(ccc))
	{
		ccc[,i]<-ccc[,i]/mean(ccc[,i])
	}
	ddd<-cbind(ddd,apply(ccc>1,1,sum))
}
sort(ddd[,1]-apply(ddd[,-c(1,2,5)],1,mean))
sort(ddd[,1]-apply(ddd[,-c(1,3,5)],1,mean))
sort(ddd[,1]-apply(ddd[,-c(1,4,5)],1,mean))

sort(ddd[,2]-apply(ddd[,-c(1,2,5)],1,mean))
sort(ddd[,2]-apply(ddd[,-c(3,2,5)],1,mean))
sort(ddd[,2]-apply(ddd[,-c(4,2,5)],1,mean))
sort(ddd[,2]-apply(ddd[,-c(2,5)],1,mean))



sort(ddd[,3]-apply(ddd[,-c(3,5)],1,mean))
sort(ddd[,3]-apply(ddd[,-c(1,3,5)],1,mean))
sort(ddd[,3]-apply(ddd[,-c(2,3,5)],1,mean))
sort(ddd[,3]-apply(ddd[,-c(4,3,5)],1,mean))


sort(ddd[,4]-apply(ddd[,-c(4,5)],1,mean))
sort(ddd[,4]-apply(ddd[,-c(3,4,5)],1,mean))

sort(ddd[,4]-apply(ddd[,-c(4,5)],1,mean))
sort(ddd[,5]-apply(ddd[,-c(5)],1,mean))
sort(ddd[,5]-apply(ddd[,-c(1,5)],1,mean))
sort(ddd[,5]-apply(ddd[,-c(2,5)],1,mean))
sort(ddd[,5]-apply(ddd[,-c(1,5)],1,mean))
sort(ddd[,5]-apply(ddd[,-c(2,5)],1,mean))
sort(ddd[,5]-apply(ddd[,-c(3,5)],1,mean))
sort(ddd[,5]-apply(ddd[,-c(4,5)],1,mean))

#################################
tg_ids<-c(1,2,3,4,5)
tg_PE_sum<-list()
for(ii in 1:length(tg_ids))
{
	tg_id<-tg_ids[ii]
	ccc<-c()
	for(i in 1:length(CMS_PE_summary))
	{
		ccc<-cbind(ccc,CMS_PE_summary[[i]][[tg_id]][[1]])
	}
	for(i in 1:ncol(ccc))
	{
		ccc[,i]<-ccc[,i]/mean(ccc[,i])
	}
	ccc<-ccc[tg_pathways,]
	ccc2<-c()
	for(i in 1:length(CMS_PE_summary))
	{
		ccc2<-cbind(ccc2,CMS_PE_summary[[i]][[tg_id]][[2]])
	}
	ccc2<-ccc2[tg_pathways,]
	colnames(ccc)<-names(CMS_PE_summary)
	colnames(ccc2)<-names(CMS_PE_summary)
	Sum_c<-list()
	for(i in 1:nrow(ccc))
	{
		Sum_c[[i]]<-list(ccc[i,],ccc2[i,])
	}
	names(Sum_c)<-rownames(ccc)
	tg_PE_sum[[ii]]<-Sum_c
}
names(tg_PE_sum)<-c("CMS1","CMS2","CMS3","CMS4","CMS_UC")


###############################


plot(c(-1, 1), c(-1, 1), type = "n", axes = FALSE, ann = FALSE, asp = 1)

aaa<-rbind(runif(8,0,1),runif(8,0,1))

library(circlize)
library(gplots)
colors = c(1:100)/100
my_palette <- colorRampPalette(c("white", "blue"))(n = 99)

plot(c(-1, 1), c(-1, 1), type = "n", axes = FALSE, ann = FALSE, asp = 1)
c_c<-c(0.1,0.1)
for(i in 1:ncol(aaa))
{
	tg_radi<-aaa[1,i]
	col_c<-my_palette[floor(aaa[2,i]*100)+1]
	draw.sector(45*i,45*(i-1),center=c_c,rou1 = tg_radi,col=col_c)
}


########
pdf("try6.pdf")

cex0<-0.5

n <- length(tg_PE_sum[[1]])
m <- length(tg_PE_sum)
rname <- names(tg_PE_sum[[1]])
cname <- names(tg_PE_sum)
   if (is.null(rname))
        rname <- 1:2*n
    if (is.null(cname))
        cname <- 1:2*m
    rname <- as.character(rname)
    cname <- as.character(cname)
par(mar = c(0, 0, 0, 0), bg = "white",lwd=0.02)
plot.new()
plot.window(c(0, 2*m+5), c(0, 2*n+5), asp = 1)
bg0="white"
plot.window(c(-1+ 0.5,2*m + 5.5), c(0, 2*n + 15 ),asp = 1, xlab="", ylab="")
text(-20, (n:1)*2-1, rname, cex = cex0)
text((1:m)*2-1, rep(2*n + 4, m), cname, srt = 90,cex = 0.4)

color_c<-c('lightblue','lightgoldenrod1','palegreen','indianred1','mediumpurple1','#ffeda0','#fee0d2','#d95f0e')
for(k in 1:m)
{
	colors = c(1:100)/100
	my_palette <- colorRampPalette(c("white", color_c[k]))(n = 99)
	for(j in 1:n)
	{
		c_c<-c((k)*2-1,(n-j+1)*2-1)
		aaa0<-rbind(tg_PE_sum[[k]][[j]][[1]],tg_PE_sum[[k]][[j]][[2]])
		aaa20<-abs(log(aaa0[2,])/log(10))
		aaa20[which(aaa20>4)]<-4
		aaa20<-aaa20/4
		aaa10<-aaa0[1,]
		aaa10[which(aaa10>2)]<-2
		aaa10<-aaa10/2
		aaa<-rbind(aaa10,aaa20)
		aaa<-aaa[,order(-aaa[1,])]
		for(i in 1:ncol(aaa))
		{
			tg_radi<-aaa[1,i]
			col_c<-my_palette[floor(aaa[2,i]*100)+1]
			draw.sector(360/ncol(aaa)*i,360/ncol(aaa)*(i-1),center=c_c,rou1 = tg_radi,col=col_c)
		}
	}
}
dev.off()

