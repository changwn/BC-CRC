ls()
load("Merged_BC_genes_all_data.RData")
load("CMS_genes.RData")
tg_list_all_CMS<-list()
tg_list_all_CMS_rate<-list()
for(i in 1:length(tg_list_all))
{
	aaa<-rep(0,length(tg_list_all[[i]]))
	bbb<-rep(0,length(tg_list_all[[i]]))
	for(j in 1:length(tg_list_all[[i]]))
	{
		ccc<-unlist(strsplit(tg_list_all[[i]][[j]],"_"))
		aaa[j]<-length(intersect(ccc,CMS_genes))
		bbb[j]<-aaa[j]/length(tg_list_all[[i]][[j]])
	}
	tg_list_all_CMS[[i]]<-aaa
	tg_list_all_CMS_rate[[i]]<-bbb
	print(i)
}
names(tg_list_all_CMS)<-names(tg_list_all)
names(tg_list_all_CMS_rate)<-names(tg_list_all)

k<-1
hist(tg_list_all_CMS_rate[[k]][which(tg_list_all_length[[k]]>10)])

pdf("CMS_genes_rate.pdf")
par(mfcol=c(3,3))
for(k in 1:length(tg_list_all_CMS_rate))
{
	hist(tg_list_all_CMS_rate[[k]][which(tg_list_all_length[[k]]>10)],main=names(tg_list_all_CMS)[k],col="lightblue")
}
dev.off()


##################################
load("sig_BC_list_all_new.RData")
tg_list_all_new<-list()
for(i in 1:length(sig_BC_list_all_new))
{
	tg_list_c<-list()
	N<-0
	names_c<-c()
	for(j in 1:length(sig_BC_list_all_new[[i]]))
	{
		for(k in 1:length(sig_BC_list_all_new[[i]][[j]]))
		{	
			N<-N+1
			tg_list_c[[N]]<-sig_BC_list_all_new[[i]][[j]][[k]][[3]]
		}
		names_c<-c(names_c,names(sig_BC_list_all_new[[i]][[j]]))
	}
	tg_list_all_new[[i]]<-tg_list_c
	names(tg_list_all_new[[i]])<-names_c
}
names(tg_list_all_new)<-names(sig_BC_list_all_new)

tg_list_all_length_new<-list()
for(i in 1:length(tg_list_all_new))
{
	aaa<-unlist(lapply(tg_list_all_new[[i]],length))
	tg_list_all_length_new[[i]]<-aaa
	names(tg_list_all_length_new[[i]])<-names(tg_list_all_new[[i]])
}
names(tg_list_all_length_new)<-names(tg_list_all_new)

save(list=c("tg_list_all_length_new","tg_list_all_new"),file="Merged_BC_genes_all_data_new.RData")
#################################

##################################
load("sig_BC_list_all_new.RData")
tg_list_all_new<-list()
for(i in 1:length(sig_BC_list_all_new))
{
	tg_list_c<-list()
	N<-0
	names_c<-c()
	for(j in 1:length(sig_BC_list_all_new[[i]]))
	{
		for(k in 1:length(sig_BC_list_all_new[[i]][[j]]))
		{	
			N<-N+1
			tg_list_c[[N]]<-sig_BC_list_all_new[[i]][[j]][[k]][[2]]
		}
		names_c<-c(names_c,names(sig_BC_list_all_new[[i]][[j]]))
	}
	tg_list_all_new[[i]]<-tg_list_c
	names(tg_list_all_new[[i]])<-names_c
}
names(tg_list_all_new)<-names(sig_BC_list_all_new)

tg_list_all_length_new<-list()
for(i in 1:length(tg_list_all_new))
{
	aaa<-unlist(lapply(tg_list_all_new[[i]],length))
	tg_list_all_length_new[[i]]<-aaa
	names(tg_list_all_length_new[[i]])<-names(tg_list_all_new[[i]])
}
names(tg_list_all_length_new)<-names(tg_list_all_new)

tg_list_sampels_new<-tg_list_all_new
tg_list_sampels_length_new<-tg_list_all_length_new
save(list=c("tg_list_sampels_length_new","tg_list_sampels_new"),file="Merged_BC_sampels_all_data_new.RData")

#################################
rm(list=ls())
load("Merged_BC_genes_all_data_new.RData")
load("CMS_genes.RData")
tg_list_all_CMS_new<-list()
tg_list_all_CMS_rate_new<-list()
for(i in 1:length(tg_list_all_new))
{
	aaa<-rep(0,length(tg_list_all_new[[i]]))
	bbb<-rep(0,length(tg_list_all_new[[i]]))
	for(j in 1:length(tg_list_all_new[[i]]))
	{
		ccc<-unlist(strsplit(tg_list_all_new[[i]][[j]],"_"))
		aaa[j]<-length(intersect(ccc,CMS_genes))
		bbb[j]<-aaa[j]/length(tg_list_all_new[[i]][[j]])
	}
	tg_list_all_CMS_new[[i]]<-aaa
	tg_list_all_CMS_rate_new[[i]]<-bbb
	print(i)
}
names(tg_list_all_CMS_new)<-names(tg_list_all_new)
names(tg_list_all_CMS_rate_new)<-names(tg_list_all_new)

k<-1
hist(tg_list_all_CMS_rate[[k]][which(tg_list_all_length[[k]]>10)])

pdf("CMS_genes_rate_new.pdf")
par(mfcol=c(3,3))
for(k in 1:length(tg_list_all_CMS_rate_new))
{
	hist(tg_list_all_CMS_rate_new[[k]][which(tg_list_all_length_new[[k]]>5)],main=names(tg_list_all_CMS_new)[k],col="lightblue")
}
dev.off()

for(i in 1:length(tg_list_all_CMS_new))
{
	print(length(tg_list_all_CMS_new[[i]]))
}

#########################
tg_list_all_new_all_genes<-list()
tg_list_all_new_up_genes<-list()
tg_list_all_new_down_genes<-list()
tg_list_all_new_all_length<-list()
tg_list_all_new_up_length<-list()
tg_list_all_new_down_length<-list()
for(i in 1:length(tg_list_all_new))
{
	tg_list_all_new_all_genes_c<-list()
	tg_list_all_new_up_genes_c<-list()
	tg_list_all_new_down_genes_c<-list()
	tg_list_all_new_all_length_c<-list()
	tg_list_all_new_up_length_c<-list()
	tg_list_all_new_down_length_c<-list()	
	for(j in 1:length(tg_list_all_new[[i]]))
	{
		ccc<-unlist(strsplit(tg_list_all_new[[i]][[j]],"_"))
		n<-length(ccc)
		ids2<-(1:(n/2))*2
		ids1<-(1:(n/2))*2-1
		tg_list_all_new_all_genes_c[[j]]<-ccc[ids1]
		tg_list_all_new_up_genes_c[[j]]<-ccc[ids1][which(ccc[ids2]=="3")]
		tg_list_all_new_down_genes_c[[j]]<-ccc[ids1][which(ccc[ids2]=="1")]
		tg_list_all_new_all_length_c[[j]]<-length(tg_list_all_new_all_genes_c[[j]])
		tg_list_all_new_up_length_c[[j]]<-length(tg_list_all_new_up_genes_c[[j]])
		tg_list_all_new_down_length_c[[j]]<-length(tg_list_all_new_down_genes_c[[j]])
	}
	names(tg_list_all_new_all_genes_c)<-names(tg_list_all_new[[i]])
	names(tg_list_all_new_up_genes_c)<-names(tg_list_all_new[[i]])
	names(tg_list_all_new_down_genes_c)<-names(tg_list_all_new[[i]])
	names(tg_list_all_new_all_length_c)<-names(tg_list_all_new[[i]])
	names(tg_list_all_new_up_length_c)<-names(tg_list_all_new[[i]])
	names(tg_list_all_new_down_length_c)<-names(tg_list_all_new[[i]])
	tg_list_all_new_all_genes[[i]]<-tg_list_all_new_all_genes_c
	tg_list_all_new_up_genes[[i]]<-tg_list_all_new_up_genes_c
	tg_list_all_new_down_genes[[i]]<-tg_list_all_new_down_genes_c
	tg_list_all_new_all_length[[i]]<-tg_list_all_new_all_length_c
	tg_list_all_new_up_length[[i]]<-tg_list_all_new_up_length_c
	tg_list_all_new_down_length[[i]]<-tg_list_all_new_down_length_c
	print(i)
}
names(tg_list_all_new_all_genes)<-names(tg_list_all_new)
names(tg_list_all_new_up_genes)<-names(tg_list_all_new)
names(tg_list_all_new_down_genes)<-names(tg_list_all_new)
names(tg_list_all_new_all_length)<-names(tg_list_all_new)
names(tg_list_all_new_up_length)<-names(tg_list_all_new)
names(tg_list_all_new_down_length)<-names(tg_list_all_new)

save(list=c(
"tg_list_all_new_all_genes",
"tg_list_all_new_up_genes",
"tg_list_all_new_down_genes",
"tg_list_all_new_all_length",
"tg_list_all_new_up_length",
"tg_list_all_new_down_length"
),file="Merged_BC_new_unique_genes_up_down.RData")

###########################################

total_DEG_list<-list()
names_all<-c()
N<-0
for(i in 1:length(tg_list_all_new_all_genes))
{
	for(j in 1:length(tg_list_all_new_all_genes[[i]]))
	{
		if(length(tg_list_all_new_all_genes[[i]][[j]])>10)
		{
			N<-N+1
			total_DEG_list[[N]]<-tg_list_all_new_all_genes[[i]][[j]]
			name_c<-paste(names(tg_list_all_new_all_genes[[i]])[j],"DEG_all",sep="_")
			names_all<-c(names_all,name_c)
		}
	}
}

for(i in 1:length(tg_list_all_new_up_genes))
{
	for(j in 1:length(tg_list_all_new_up_genes[[i]]))
	{
		if(length(tg_list_all_new_up_genes[[i]][[j]])>10)
		{
			N<-N+1
			total_DEG_list[[N]]<-tg_list_all_new_up_genes[[i]][[j]]
			name_c<-paste(names(tg_list_all_new_up_genes[[i]])[j],"DEG_up",sep="_")
			names_all<-c(names_all,name_c)
		}
	}
}

for(i in 1:length(tg_list_all_new_down_genes))
{
	for(j in 1:length(tg_list_all_new_down_genes[[i]]))
	{
		if(length(tg_list_all_new_down_genes[[i]][[j]])>10)
		{
			N<-N+1
			total_DEG_list[[N]]<-tg_list_all_new_down_genes[[i]][[j]]
			name_c<-paste(names(tg_list_all_new_down_genes[[i]])[j],"DEG_down",sep="_")
			names_all<-c(names_all,name_c)
		}
	}
}
names(total_DEG_list)<-names_all
save(list="total_DEG_list",file="total_DEG_list.RData")


