length(list.analysis.CMS.enrich)
names(list.analysis.CMS.enrich)

length(list.analysis.CMS.enrich[[1]])
names(list.analysis.CMS.enrich[[1]])


length(list.analysis.CMS.enrich[[1]][[5]])
names(list.analysis.CMS.enrich[[1]][[5]])

colnames(list.analysis.CMS.enrich[[1]][[5]])
rownames(list.analysis.CMS.enrich[[1]][[5]])

head(list.analysis.CMS.enrich[[1]][[5]])
dim(list.analysis.CMS.enrich[[1]][[5]])



hist(list.analysis.CMS.enrich[[1]][[5]][,"p_CMS1"])
hist(list.analysis.CMS.enrich[[1]][[5]][,"p_CMS2"])
hist(list.analysis.CMS.enrich[[1]][[5]][,"p_CMS3"])
hist(list.analysis.CMS.enrich[[1]][[5]][,"p_CMS4"])
hist(list.analysis.CMS.enrich[[1]][[5]][,"p_CMS5"])
hist(list.analysis.CMS.enrich[[1]][[5]][,"p_CMS6"])



pdf("CMS_enrichment.pdf")
par(mfcol=c(3,2))
for(i in 1:length(list.analysis.CMS.enrich))
{
	for(j in 1:length(list.analysis.CMS.enrich[[i]]))
	{
		for(k in 9:14)
		{
			if(length(list.analysis.CMS.enrich[[i]][[j]])>0)
			{
				hist(list.analysis.CMS.enrich[[i]][[j]][,k],
				main=paste(names(list.analysis.CMS.enrich)[i],
				names(list.analysis.CMS.enrich[[i]])[j],
				colnames(list.analysis.CMS.enrich[[i]][[j]])[k],sep="\n"),col="lightblue",xlim=c(0,1))
			}
		}
	}
}
dev.off()

head(list.analysis.CMS.clinical[[4]][[5]])



head(list.analysis.CMS.clinical[[6]][[5]])
head(list.analysis.CMS.clinical[[7]][[5]])


head(list.analysis.CMS.clinical[[9]][[4]])
head(list.analysis.CMS.clinical[[10]][[5]])

hist(list.analysis.CMS.survial[[10]][[5]][,1])
hist(list.analysis.CMS.survial[[10]][[5]][,2])
hist(list.analysis.CMS.survial[[10]][[5]][,3])
hist(list.analysis.CMS.survial[[10]][[5]][,4])
hist(list.analysis.CMS.survial[[10]][[5]][,5])
hist(list.analysis.CMS.survial[[10]][[5]][,6])

par(mfcol=c(3,2))
hist(list.analysis.CMS.survial[[5]][[5]][,1])
hist(list.analysis.CMS.survial[[5]][[5]][,2])
hist(list.analysis.CMS.survial[[5]][[5]][,3])
hist(list.analysis.CMS.survial[[5]][[5]][,4])
hist(list.analysis.CMS.survial[[5]][[5]][,5])
hist(list.analysis.CMS.survial[[5]][[5]][,6])

names(list.analysis.CMS.clinical)[10]<-"TCGA_COAD"
names(list.analysis.CMS.enrich)[10]<-"TCGA_COAD"

for(i in 1:9)
{
	names(list.analysis.CMS.enrich)[i]<-unlist(strsplit(names(list.analysis.CMS.enrich)[i],"_"))[2]
}

load("CMS_sample_list_all.RData")

names(list.analysis.CMS.survial)[10]<-"TCGA_COAD"
names_index<-names(list.analysis.CMS.survial)
names(D)<-names(list.analysis.CMS.enrich)

load("PE_all_list.RData")
load("TCGA_PE_all_list.RData")

length(CMS_sample_list_all_GEO)
CMS_BC_enrich_list<-list()
CMS_BC_enrich_stat<-c()
for(i in 1:7)
{
	tg_id<-names(CMS_sample_list_all_GEO)[i]
	ddd<-list.analysis.CMS.enrich[[tg_id]]
	s00_a<-c()
	s10_a<-c()
	s20_a<-c()
	s30_a<-c()
	s40_a<-c()
	s50_a<-c()
	s60_a<-c()
	s70_a<-c()
	for(j in 1:length(ddd))
	{
		ccc<-ddd[[j]]
		tg_ind<-paste(names_index[tg_id],"_RMA_MAP_filter_",names(ddd)[j],sep="")
		BC_names<-rownames(ccc)
		for(k in 1:length(BC_names))
		{
			BC_names[k]<-paste("BC_",unlist(strsplit(BC_names[k],"BC"))[2],sep="")
		}
		names1<-paste(tg_ind,BC_names,sep="_")
		names2<-paste(tg_ind,BC_names,"DEG_all",sep="_")
		nnames<-cbind(names1,names2)
		rownames(nnames)<-names2
		rownames(ccc)<-names1
		print(c(i,j,length(names2),length(intersect(names2,names(PE_all_list)))))
		ccc0<-ccc[nnames[intersect(names2,names(PE_all_list)),1],]
		s1<-rownames(ccc0)[which(ccc0[,"p_CMS1"]<0.01)]
		s2<-rownames(ccc0)[which(ccc0[,"p_CMS2"]<0.01)]
		s3<-rownames(ccc0)[which(ccc0[,"p_CMS3"]<0.01)]
		s4<-rownames(ccc0)[which(ccc0[,"p_CMS4"]<0.01)]
		s5<-rownames(ccc0)[which(ccc0[,"p_CMS5"]<0.05)]
		s6<-rownames(ccc0)[which(ccc0[,"p_CMS6"]<0.05)]
		s7<-names(which(table(c(s1,s2,s3,s4,s5,s6))>1))
		s0<-rownames(ccc0)
		s10<-setdiff(s1,s7)
		s20<-setdiff(s2,s7)
		s30<-setdiff(s3,s7)
		s40<-setdiff(s4,s7)
		s50<-setdiff(s5,s7)
		s60<-setdiff(s6,s7)
		s70<-s7
		s00<-setdiff(s0,unique(c(s1,s2,s3,s4,s5,s6,s7)))
		s00_a<-c(s00_a,s00)
		s10_a<-c(s10_a,s10)
		s20_a<-c(s20_a,s20)
		s30_a<-c(s30_a,s30)
		s40_a<-c(s40_a,s40)
		s50_a<-c(s50_a,s50)
		s60_a<-c(s60_a,s60)
		s70_a<-c(s70_a,s70)
	}
	fff<-c(length(s10_a),length(s20_a),length(s30_a),length(s40_a),length(s50_a),length(s60_a),length(s70_a),length(s00_a))
	fff<-fff/sum(fff)
	names(fff)<-c("CMS1","CMS2","CMS3","CMS4","Multi-CMS","None","Multi-class","Insignificant")
	CMS_BC_enrich_stat<-rbind(CMS_BC_enrich_stat,fff)
	ll_c<-list(s10_a,s20_a,s30_a,s40_a,s50_a,s60_a,s70_a,s00_a)
	names(ll_c)<-c("CMS1","CMS2","CMS3","CMS4","Multi-CMS","None","Multi-class","Insignificant")
	CMS_BC_enrich_list[[i]]<-ll_c
}

names(TCGA_PE_all_list)

rownames(CMS_BC_enrich_stat)<-names(CMS_sample_list_all_GEO)[1:7]
names(CMS_BC_enrich_list)<-names(CMS_sample_list_all_GEO)[1:7]

i<-8
tg_id<-names(CMS_sample_list_all_GEO)[i]
ddd<-list.analysis.CMS.enrich[[tg_id]]
	s00_a<-c()
	s10_a<-c()
	s20_a<-c()
	s30_a<-c()
	s40_a<-c()
	s50_a<-c()
	s60_a<-c()
	s70_a<-c()
	for(j in 1:length(ddd))
	{
		ccc<-ddd[[j]]
		tg_ind<-paste(names_index[tg_id],"_FPKM_T_RMA_MAP_filter_",names(ddd)[j],sep="")
		BC_names<-rownames(ccc)
		for(k in 1:length(BC_names))
		{
			BC_names[k]<-paste("BC_",unlist(strsplit(BC_names[k],"BC"))[2],sep="")
		}
		names1<-paste(tg_ind,BC_names,sep="_")
		names2<-paste(tg_ind,BC_names,"DEG_all",sep="_")
		nnames<-cbind(names1,names2)
		rownames(nnames)<-names1
		rownames(ccc)<-names1
		print(c(i,j,length(names2),length(intersect(names1,names(TCGA_PE_all_list)))))
		ccc0<-ccc[nnames[intersect(names1,names(TCGA_PE_all_list)),1],]
		s1<-rownames(ccc0)[which(ccc0[,"p_CMS1"]<0.01)]
		s2<-rownames(ccc0)[which(ccc0[,"p_CMS2"]<0.01)]
		s3<-rownames(ccc0)[which(ccc0[,"p_CMS3"]<0.01)]
		s4<-rownames(ccc0)[which(ccc0[,"p_CMS4"]<0.01)]
		s5<-rownames(ccc0)[which(ccc0[,"p_CMS5"]<0.05)]
		s6<-rownames(ccc0)[which(ccc0[,"p_CMS6"]<0.05)]
		s7<-names(which(table(c(s1,s2,s3,s4,s5,s6))>1))
		s0<-rownames(ccc0)
		s10<-setdiff(s1,s7)
		s20<-setdiff(s2,s7)
		s30<-setdiff(s3,s7)
		s40<-setdiff(s4,s7)
		s50<-setdiff(s5,s7)
		s60<-setdiff(s6,s7)
		s70<-s7
		s00<-setdiff(s0,unique(c(s1,s2,s3,s4,s5,s6,s7)))
		s00_a<-c(s00_a,s00)
		s10_a<-c(s10_a,s10)
		s20_a<-c(s20_a,s20)
		s30_a<-c(s30_a,s30)
		s40_a<-c(s40_a,s40)
		s50_a<-c(s50_a,s50)
		s60_a<-c(s60_a,s60)
		s70_a<-c(s70_a,s70)
	}
	fff<-c(length(s10_a),length(s20_a),length(s30_a),length(s40_a),length(s50_a),length(s60_a),length(s70_a),length(s00_a))
	fff<-fff/sum(fff)
	names(fff)<-c("CMS1","CMS2","CMS3","CMS4","Multi-CMS","None","Multi-class","Insignificant")
	CMS_BC_enrich_stat<-rbind(CMS_BC_enrich_stat,fff)
	ll_c<-list(s10_a,s20_a,s30_a,s40_a,s50_a,s60_a,s70_a,s00_a)
	names(ll_c)<-c("CMS1","CMS2","CMS3","CMS4","Multi-CMS","None","Multi-class","Insignificant")
	CMS_BC_enrich_list[[i]]<-ll_c

names(CMS_BC_enrich_list)[8]<-"TCGA_COAD"
rownames(CMS_BC_enrich_stat)[8]<-"TCGA_COAD"

save(list=c("CMS_BC_enrich_list","CMS_BC_enrich_stat"),file="CMS_BC_enrich_list.RData")

pdf("CMS_BC_enrich_rate.pdf")
par(xpd=T, mar=par()$mar+c(2,0,0,10))

barplot(t(CMS_BC_enrich_stat[,-8]),ylim=c(0,1),
col=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen","white"),las=2, yaxt="n")

library(scales)
dates <-  1:100
returns <- runif(100)
yticks_val <- pretty_breaks(n=5)(returns)
axis(2, at=yticks_val, lab=percent(yticks_val))
legend(10, 1, colnames(CMS_BC_enrich_stat), fill=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen","white"));
dev.off()

#######################
CMS_BC_enrich_stat2<-CMS_BC_enrich_stat

colnames(CMS_BC_enrich_stat2)[5]<-"None"
colnames(CMS_BC_enrich_stat2)[6]<-"Multi-CMS"

pdf("CMS_BC_enrich_rate2.pdf")
par(xpd=T, mar=par()$mar+c(2,0,0,10))

barplot(t(CMS_BC_enrich_stat2[,-8]),ylim=c(0,1),
col=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen","white"),las=2, yaxt="n")

library(scales)
dates <-  1:100
returns <- runif(100)
yticks_val <- pretty_breaks(n=5)(returns)
axis(2, at=yticks_val, lab=percent(yticks_val))
legend(10, 1, colnames(CMS_BC_enrich_stat2), fill=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen","white"));
dev.off()

###############################################################################
load("CMS_genes.RData")
load("TCGA_total_DEG_list.RData")
TCGA_total_DEG_list<-total_DEG_list
load("total_DEG_list.RData")

pdf("CMS_genes_BC_genes_overlap3.pdf")
par(xpd=T, mar=par()$mar+c(10,0,0,10))
for(i in 1:length(CMS_BC_enrich_list))
{
	tg_list_c<-list()
	for(j in 1:length(CMS_BC_enrich_list[[i]]))
	{
		ccc<-CMS_BC_enrich_list[[i]][[j]]
		if(i!=8)
		{
			ddd<-paste(ccc,"_DEG_all",sep="")
			eee<-c()
			for(k in 1:length(ddd))
			{
				tg_genes<-total_DEG_list[[ddd[k]]]
				eee<-c(eee,length(intersect(tg_genes,CMS_genes))/length(tg_genes))
			}
			tg_list_c[[j]]<-eee
		}
		if(i==8)
		{
			ddd<-ccc
			eee<-c()
			for(k in 1:length(ddd))
			{
				tg_genes<-TCGA_total_DEG_list[[ddd[k]]]
				eee<-c(eee,length(intersect(tg_genes,CMS_genes))/length(tg_genes))
			}
			tg_list_c[[j]]<-eee
		}
		
	}
	names(tg_list_c)<-names(CMS_BC_enrich_list[[i]])
	boxplot(tg_list_c,ylim=c(0,1),las=2,
	col=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen","white"),
	main=names(CMS_BC_enrich_list)[i])
	print(i)
}
dev.off()

clinical_sig<-list()
N<-0
for(i in c(1:7,10))
{
	ddd<-c()
	for(j in 1:length(list.analysis.CMS.survial[[i]]))
	{
		ccc<-list.analysis.CMS.survial[[i]][[j]]
		ccc<-as.matrix(ccc)
		ccc[which(is.na(ccc)==1)]<-2
		eee<-ccc[which(apply(ccc<0.01,1,sum)>0),]
		if(length(which(apply(ccc<0.01,1,sum)>0))==1)
		{
			eee<-ccc[c(which(apply(ccc<0.01,1,sum)>0),which(apply(ccc<0.01,1,sum)>0)),]
		}
		if(length(which(apply(ccc<0.01,1,sum)>0))>0)
		{
		if(i!=10)
		{
			tg_id<-i
			tg_ind<-paste(names_index[tg_id],"_RMA_MAP_filter_",names(list.analysis.CMS.survial[[i]])[j],sep="")
			BC_names<-rownames(eee)
			for(k in 1:length(BC_names))
			{
				BC_names[k]<-paste("BC_",unlist(strsplit(BC_names[k],"BC"))[2],sep="")
			}
			names1<-paste(tg_ind,BC_names,sep="_")
			names2<-paste(tg_ind,BC_names,"DEG_all",sep="_")
			nnames<-cbind(names1,names2)
			rownames(nnames)<-names2
			rownames(eee)<-names1
			print(c(i,j,length(names2),length(intersect(names2,names(PE_all_list)))))
			eee0<-eee[nnames[intersect(names2,names(PE_all_list)),1],]
			if(length(nnames[intersect(names2,names(PE_all_list)),1])==1)
			{
				eee0<-t(as.matrix(eee0))
			}
			rownames(eee0)<-nnames[intersect(names2,names(PE_all_list)),1]
		}
		if(i==10)
		{
			tg_id<-10
			tg_ind<-paste(names_index[10],"_FPKM_T_RMA_MAP_filter_",names(list.analysis.CMS.survial[[i]])[j],sep="")
			BC_names<-rownames(eee)
			for(k in 1:length(BC_names))
			{
				BC_names[k]<-paste("BC_",unlist(strsplit(BC_names[k],"BC"))[2],sep="")
			}
			names1<-paste(tg_ind,BC_names,sep="_")
			rownames(eee)<-names1
			print(c(i,j,length(names1),length(intersect(names1,names(TCGA_PE_all_list)))))
			eee0<-eee
		}
		ddd<-rbind(ddd,eee0)
		}
	}
	N<-N+1
	clinical_sig[[N]]<-ddd
}
names(clinical_sig)<-names(list.analysis.CMS.survial)[c(1:7,10)]

for(i in 1:length(clinical_sig))
{
	print(head(clinical_sig[[i]]))
}


key<-"dfs_in_1"
p_cut<-0.05

N<-0
PE_all_ccc<-list()
for(i in 1:length(clinical_sig))
{
	if(sum(colnames(clinical_sig[[i]])==key)>0)
	{
		print(i)
		print(names(which(clinical_sig[[i]][,key]<p_cut)))
		ccc<-names(which(clinical_sig[[i]][,key]<p_cut))
		PE_all_c<-c()
		if(length(ccc)>0)
		{
			N<-N+1
			if(i!=8)
			{
				ccc0<-paste(ccc,"_DEG_down",sep="")
				for(k in 1:length(ccc0))
				{
					ddd<-names(PE_all_list[[ccc0[k]]])
					PE_all_c<-c(PE_all_c,ddd)
				}
				ccc0<-paste(ccc,"_DEG_up",sep="")
				for(k in 1:length(ccc0))
				{
					ddd<-names(PE_all_list[[ccc0[k]]])
					PE_all_c<-c(PE_all_c,ddd)
				}
			}
			else
			{
				for(k in 1:length(ccc))
				{
					ddd<-names(TCGA_PE_all_list[[ccc[k]]])
					PE_all_c<-c(PE_all_c,ddd)
				}
			}
			PE_all_ccc[[N]]<-PE_all_c
		}
	}
}

names(which(table(PE_all_ccc[[1]])>1))
intersect(
intersect(
names(which(table(PE_all_ccc[[2]])>1))
,
names(which(table(PE_all_ccc[[3]])>1))
),
names(which(table(PE_all_ccc[[4]])>2))
)

sort(table(c(names(which(table(PE_all_ccc[[1]])>1)),
names(which(table(PE_all_ccc[[2]])>0)),
names(which(table(PE_all_ccc[[3]])>3)),
names(which(table(PE_all_ccc[[4]])>1)),
names(which(table(PE_all_ccc[[5]])>4)),
names(which(table(PE_all_ccc[[6]])>3)))))


intersect(
intersect(
names(which(table(PE_all_ccc[[3]])>10))
,
names(which(table(PE_all_ccc[[1]])>1))
),
names(which(table(PE_all_ccc[[2]])>3))
)
names(which(table(PE_all_ccc[[1]])>2))

intersect(
names(which(table(PE_all_ccc[[1]])>2))
,
names(which(table(PE_all_ccc[[2]])>0))
)


intersect(
intersect(
names(which(table(PE_all_ccc[[2]])>2))
,
names(which(table(PE_all_ccc[[3]])>2))
),
names(which(table(PE_all_ccc[[4]])>2))
)

intersect(
intersect(
names(which(table(PE_all_ccc[[3]])>4))
,
names(which(table(PE_all_ccc[[2]])>4))
),
names(which(table(PE_all_ccc[[4]])>4))
)

intersect(
names(which(table(PE_all_ccc[[1]])>1))
,
names(which(table(PE_all_ccc[[4]])>4))
)
intersect(
names(which(table(PE_all_ccc[[2]])>3))
,
names(which(table(PE_all_ccc[[3]])>3))
)

hist(list.analysis.CMS.survial[[3]][[5]][,1])
hist(list.analysis.CMS.survial[[4]][[5]][,2])
hist(list.analysis.CMS.survial[[5]][[5]][,2])
hist(list.analysis.CMS.survial[[10]][[5]][,1])
hist(list.analysis.CMS.survial[[2]][[5]][,1])

#############################3

CMS_BC_enrich_list
clinical_sig
length(CMS_BC_enrich_list)
length(clinical_sig)


key_c<-"dfs"
names_data<-names(CMS_sample_list_all_GEO)
ddd<-c()
rnames_c<-c()
for(tg_id in names_data)
{
	i<-names_index[[tg_id]]
	aaa<-0
	ddd_c<-c()
	iddd<-agrep(key_c,colnames(clinical_sig[[i]]),max.distance=0)
	if(length(iddd)>0)
	{
		eee<-clinical_sig[[i]][,iddd]
		for(j in 1:length(CMS_BC_enrich_list[[tg_id]]))
		{
			aaa<-aaa+length(CMS_BC_enrich_list[[tg_id]][[j]])
			fff<-names(which(apply(eee<0.05,1,sum)>0))
			ddd_c<-c(ddd_c,length(intersect(CMS_BC_enrich_list[[tg_id]][[j]],fff)))
		}
		rnames_c<-c(rnames_c,tg_id)
	}
	ddd<-rbind(ddd,ddd_c)
	print(c(i,aaa,nrow(clinical_sig[[i]])))
}
rownames(ddd)<-rnames_c
colnames(ddd)<-colnames(CMS_BC_enrich_stat)
colnames(ddd)<-c("CMS1","CMS2","CMS3","CMS4","None","Multi-CMS","Multi-class","Insignificant")

for(i in 1:nrow(ddd))
{
	ddd[i,]<-ddd[i,]/sum(ddd[i,])
}

pdf("dfs_CMS_rate.pdf")
par(xpd=T, mar=par()$mar+c(2,0,0,9))

barplot(t(ddd[,-8]),ylim=c(0,1),
col=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen","white"),las=2, yaxt="n")

library(scales)
dates <-  1:100
returns <- runif(100)
yticks_val <- pretty_breaks(n=5)(returns)
axis(2, at=yticks_val, lab=percent(yticks_val))
legend(9, 1, colnames(ddd), fill=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen","white"));
dev.off()
dfs_CMS_rate<-ddd
###############
key_c<-"os"
names_data<-names(CMS_sample_list_all_GEO)
ddd<-c()
rnames_c<-c()
for(tg_id in names_data)
{
	i<-names_index[[tg_id]]
	aaa<-0
	ddd_c<-c()
	iddd<-agrep(key_c,colnames(clinical_sig[[i]]),max.distance=0)
	if(length(iddd)>0)
	{
		eee<-clinical_sig[[i]][,iddd]
		for(j in 1:length(CMS_BC_enrich_list[[tg_id]]))
		{
			aaa<-aaa+length(CMS_BC_enrich_list[[tg_id]][[j]])
			fff<-names(which(apply(eee<0.05,1,sum)>0))
			ddd_c<-c(ddd_c,length(intersect(CMS_BC_enrich_list[[tg_id]][[j]],fff)))
		}
		rnames_c<-c(rnames_c,tg_id)
	}
	ddd<-rbind(ddd,ddd_c)
	print(c(i,aaa,nrow(clinical_sig[[i]])))
}
rownames(ddd)<-rnames_c
colnames(ddd)<-colnames(CMS_BC_enrich_stat)
colnames(ddd)<-c("CMS1","CMS2","CMS3","CMS4","None","Multi-CMS","Multi-class","Insignificant")
for(i in 1:nrow(ddd))
{
	ddd[i,]<-ddd[i,]/sum(ddd[i,])
}


ddd0<-ddd

key_c<-"dss"
names_data<-names(CMS_sample_list_all_GEO)
ddd<-c()
rnames_c<-c()
for(tg_id in names_data)
{
	i<-names_index[[tg_id]]
	aaa<-0
	ddd_c<-c()
	iddd<-agrep(key_c,colnames(clinical_sig[[i]]),max.distance=0)
	if(length(iddd)>0)
	{
		eee<-clinical_sig[[i]][,iddd]
		for(j in 1:length(CMS_BC_enrich_list[[tg_id]]))
		{
			aaa<-aaa+length(CMS_BC_enrich_list[[tg_id]][[j]])
			fff<-names(which(apply(eee<0.05,1,sum)>0))
			ddd_c<-c(ddd_c,length(intersect(CMS_BC_enrich_list[[tg_id]][[j]],fff)))
		}
		rnames_c<-c(rnames_c,tg_id)
	}
	ddd<-rbind(ddd,ddd_c)
	print(c(i,aaa,nrow(clinical_sig[[i]])))
}
rownames(ddd)<-rnames_c
colnames(ddd)<-colnames(CMS_BC_enrich_stat)
colnames(ddd)<-c("CMS1","CMS2","CMS3","CMS4","None","Multi-CMS","Multi-class","Insignificant")

for(i in 1:nrow(ddd))
{
	ddd[i,]<-ddd[i,]/sum(ddd[i,])
}

ddd0<-rbind(ddd0,ddd)
ddd0<-ddd0[-1,]

ddd0<-ddd0[sort(rownames(ddd0)),]

pdf("os_CMS_rate2.pdf")
par(xpd=T, mar=par()$mar+c(2,0,0,15))

barplot(t(ddd0[,-8]),ylim=c(0,1),
col=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen","white"),las=2, yaxt="n")

library(scales)
dates <-  1:100
returns <- runif(100)
yticks_val <- pretty_breaks(n=5)(returns)
axis(2, at=yticks_val, lab=percent(yticks_val))
legend(7, 1, colnames(ddd0), fill=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen","white"));
dev.off()

os_CMS_rate<-ddd0
save(list=c("os_CMS_rate","dfs_CMS_rate"),file="dfs_os_CMS_rate.RData")
#######

key_c<-"dss"
names_data<-names(CMS_sample_list_all_GEO)
ddd<-c()
rnames_c<-c()
for(tg_id in names_data)
{
	i<-names_index[[tg_id]]
	aaa<-0
	ddd_c<-c()
	iddd<-agrep(key_c,colnames(clinical_sig[[i]]),max.distance=0)
	if(length(iddd)>0)
	{
		eee<-as.matrix(clinical_sig[[i]][,iddd])
		for(j in 1:length(CMS_BC_enrich_list[[tg_id]]))
		{
			aaa<-aaa+length(CMS_BC_enrich_list[[tg_id]][[j]])
			fff<-names(which(apply(eee<0.05,1,sum)>0))
			ddd_c<-c(ddd_c,length(intersect(CMS_BC_enrich_list[[tg_id]][[j]],fff)))
		}
		rnames_c<-c(rnames_c,tg_id)
	}
	ddd<-rbind(ddd,ddd_c)
	print(c(i,aaa,nrow(clinical_sig[[i]])))
}
rownames(ddd)<-rnames_c
colnames(ddd)<-colnames(CMS_BC_enrich_stat)
for(i in 1:nrow(ddd))
{
	ddd[i,]<-ddd[i,]/sum(ddd[i,])
}

par(xpd=T, mar=par()$mar+c(2,0,0,10))

barplot(t(ddd[,-8]),ylim=c(0,1),
col=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen","white"),las=2, yaxt="n")

library(scales)
dates <-  1:100
returns <- runif(100)
yticks_val <- pretty_breaks(n=5)(returns)
axis(2, at=yticks_val, lab=percent(yticks_val))
legend(10, 1, colnames(CMS_BC_enrich_stat), fill=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen","white"));
##########################################

load("sig_BC_list_all_new_pp.RData")
load("TCGA_sig_BC_list_all_new_pp.RData")

load("list.analysis.CMS.2017-03-25.RData")

sig_BC_pp_all

PE_all_list
list.analysis.CMS.clinical
clinical_sig

p_cut_PE<-0.005
BC_sig_allways_stat<-list()
for(i in 1:length(CMS_BC_enrich_list))
{
	tg_id<-names_index[[names(CMS_BC_enrich_list)[i]]]
	if(i<8)
	{
		ccc<-sig_BC_pp_all[[tg_id]]
		tgs<-names(sort(ccc[,7]))
		ddd<-matrix(0,length(tgs),4)
		rownames(ddd)<-tgs
		colnames(ddd)<-c("PE","CMS","survival","clinical")
		for(j in 1:length(tgs))
		{
			tg1<-paste(tgs[j],"_DEG_all",sep="")
			tg2<-paste(tgs[j],"_DEG_up",sep="")
			tg3<-paste(tgs[j],"_DEG_down",sep="")
			ddd[j,1]<-sum(PE_all_list[[tg1]]<p_cut_PE)+sum(PE_all_list[[tg2]]<p_cut_PE)+sum(PE_all_list[[tg3]]<p_cut_PE)
		}
	}
	if(i==8)
	{
		ccc<-TCGA_sig_BC_pp_all[[1]]
		tgs<-names(sort(ccc[,7]))
		ddd<-matrix(0,length(tgs),4)
		rownames(ddd)<-tgs
		colnames(ddd)<-c("PE","CMS","survival","clinical")
		for(j in 1:length(tgs))
		{
			tg1<-tgs[j]
			ddd[j,1]<-sum(TCGA_PE_all_list[[tg1]]<p_cut_PE)
		}
	}
	fff<-CMS_BC_enrich_list[[names(CMS_BC_enrich_list)[i]]]
	for(j in 1:7)
	{
		tgs_c<-fff[[j]]
		ddd[tgs_c,2]<-j
	}
	ddd[rownames(clinical_sig[[tg_id]]),3]<-1
	ggg<-list.analysis.CMS.clinical[[tg_id]]
	for(j in 1:length(ggg))
	{
		hhh<-ggg[[j]]
		hhh0<-hhh*0
		for(k in 1:ncol(hhh))
		{
			iii<-hhh[,k]
			tg_ids<-which(is.na(iii)==1)
			if(length(tg_ids)>0)
			{
				iii[tg_ids]<-1
			}
			iii<-iii*100
			hhh0[,k]<-iii
		}
		BC_names<-names(which(apply(hhh0<0.05,1,sum)!=0))
		if(length(BC_names)>0)
		{
			for(k in 1:length(BC_names))
			{
				BC_names[k]<-paste("BC_",unlist(strsplit(BC_names[k],"BC"))[2],sep="")
			}
			tg_ind<-paste(tg_id,"_RMA_MAP_filter_",names(ggg)[j],sep="")
			if(i==8)
			{
				tg_ind<-paste(tg_id,"_FPKM_T_RMA_MAP_filter_",names(ggg)[j],sep="")
			}
			names1<-paste(tg_ind,BC_names,sep="_")
			ddd[names1,4]<-1
		}
	}
	print(i)
	BC_sig_allways_stat[[i]]<-ddd
}

names(BC_sig_allways_stat)<-names(CMS_BC_enrich_list)

par(mfcol=c(2,4))
for(i in 1:length(BC_sig_allways_stat))
{
	ccc<-plot_p(apply(BC_sig_allways_stat[[i]]>0,1,sum)>0)
	plot(ccc,main=names(BC_sig_allways_stat)[i],type="l",ylim=c(0,1))
}

plot_p<-function(aaa)
{
	bbb<-cumsum(aaa)/(1:length(aaa))
	#plot(cumsum(aaa)/(1:length(aaa)),type="l")
	return(bbb)
}

pdf("BC_sig_allways.pdf")
par(mfcol=c(2,2))
for(i in 1:length(BC_sig_allways_stat))
{
	for(j in 1:ncol(BC_sig_allways_stat[[i]]))
	{
		ccc<-plot_p(BC_sig_allways_stat[[i]][,j]>0)
		plot(ccc,main=paste(names(BC_sig_allways_stat)[i],colnames(BC_sig_allways_stat[[i]])[j]),type="l",ylim=c(0,1))
	}
}
dev.off()


pdf("BC_sig_allways2.pdf")
par(mfcol=c(2,2))
for(i in 1:length(BC_sig_allways_stat))
{
	for(j in 1:ncol(BC_sig_allways_stat[[i]]))
	{
		ccc<-plot_p(BC_sig_allways_stat[[i]][,j]>0)
		plot(ccc,main=paste(names(BC_sig_allways_stat)[i],colnames(BC_sig_allways_stat[[i]])[j]),type="l")
	}
}
dev.off()


pdf("BC_meaningful_percentile.pdf")
i<-1
ccc<-plot_p(apply(BC_sig_allways_stat[[i]]>0,1,sum)>0)
plot(ccc[-c(1:10)],main="",type="l",ylim=c(0.4,1),col=2,lwd=2,xlab="",ylab="", yaxt="n")
print(length(ccc))
for(i in 2:length(BC_sig_allways_stat))
{
	ccc<-plot_p(apply(BC_sig_allways_stat[[i]]>0,1,sum)>0)
	points(ccc[-c(1:10)],type="l",ylim=c(0,1),col=i+1,lwd=2)
	print(length(ccc))
}

legend(5700, 0.995, names(BC_sig_allways_stat), fil=c(2:9))

library(scales)
dates <-  1:100
returns <- runif(100)
yticks_val <- pretty_breaks(n=5)(returns)
axis(2, at=yticks_val, lab=percent(yticks_val))
dev.off()
##############################################
for(i in 1:length(CMS_BC_enrich_list))
{
	ccc<-0
	for(j in 1:length(CMS_BC_enrich_list[[i]]))
	{
		ccc<-ccc+length(CMS_BC_enrich_list[[i]][[j]])
	}
	print(ccc)
}


BC_sig_allways_stat_old<-BC_sig_allways_stat
for(i in 1:length(BC_sig_allways_stat))
{
	ccc<-c()
	for(j in 1:length(CMS_BC_enrich_list[[i]]))
	{
		ccc<-c(ccc,CMS_BC_enrich_list[[i]][[j]])
	}
	ccc0<-BC_sig_allways_stat[[i]]
	BC_sig_allways_stat[[i]]<-ccc0[intersect(rownames(ccc0),ccc),]
}


pdf("BC_sig_allways_types.pdf")
j<-1
i<-1
	ccc<-plot_p(BC_sig_allways_stat[[i]][,j]>0)
	xxx<-c(1:length(ccc))/length(ccc)
	plot(ccc~xxx,col=2,main="Pathway Enrichment",type="l",ylim=c(0.2,1),xlab="",ylab="")
	for(i in 2:length(BC_sig_allways_stat))
	{	
		
		ccc<-plot_p(BC_sig_allways_stat[[i]][,j]>0)
		xxx<-c(1:length(ccc))/length(ccc)
		points(ccc~xxx,type="l",col=i+1)
	}

j<-2
i<-1
	ccc<-plot_p(BC_sig_allways_stat[[i]][,j]>0)
	ccc<-ccc[-c(1:20)]
	xxx<-c(1:length(ccc))/length(ccc)
	plot(ccc~xxx,col=2,main=colnames(BC_sig_allways_stat[[i]])[j],type="l",ylim=c(0.1,0.8),xlab="",ylab="",cex=2)
	for(i in 2:length(BC_sig_allways_stat))
	{	
		
		ccc<-plot_p(BC_sig_allways_stat[[i]][,j]>0)
		ccc<-ccc[-c(1:20)]
		xxx<-c(1:length(ccc))/length(ccc)
		points(ccc~xxx,type="l",col=i+1)
	}

j<-3
i<-1
	ccc<-plot_p(BC_sig_allways_stat[[i]][,j]>0)
	ccc<-ccc[-c(1:20)]
	xxx<-c(1:length(ccc))/length(ccc)
	plot(ccc~xxx,col=2,main="Survival",type="l",ylim=c(0.0,0.15),xlab="",ylab="",cex=2)
	for(i in 2:length(BC_sig_allways_stat))
	{	
		
		ccc<-plot_p(BC_sig_allways_stat[[i]][,j]>0)
		ccc<-ccc[-c(1:20)]	
		xxx<-c(1:length(ccc))/length(ccc)
		points(ccc~xxx,type="l",col=i+1)
	}

dev.off()


pdf("BC_sig_allways_new.pdf")
par(mfcol=c(2,2))
for(i in 1:length(BC_sig_allways_stat))
{
	for(j in 1:ncol(BC_sig_allways_stat[[i]]))
	{
		ccc<-plot_p(BC_sig_allways_stat[[i]][,j]>0)
		plot(ccc,main=paste(names(BC_sig_allways_stat)[i],colnames(BC_sig_allways_stat[[i]])[j]),type="l",ylim=c(0,1))
	}
}
dev.off()


pdf("BC_sig_allways_new2.pdf")
par(mfcol=c(2,2))
for(i in 1:length(BC_sig_allways_stat))
{
	for(j in 1:ncol(BC_sig_allways_stat[[i]]))
	{
		ccc<-plot_p(BC_sig_allways_stat[[i]][,j]>0)
		plot(ccc,main=paste(names(BC_sig_allways_stat)[i],colnames(BC_sig_allways_stat[[i]])[j]),type="l")
	}
}
dev.off()


pdf("BC_meaningful_percentile_new2.pdf")
i<-1
ccc<-plot_p(apply(BC_sig_allways_stat[[i]]>0,1,sum)>0)
plot(ccc[-c(1:10)],main="",type="l",ylim=c(0.4,1),col=2,lwd=2,xlab="",ylab="", yaxt="n")
print(length(ccc))
for(i in 2:length(BC_sig_allways_stat))
{
	ccc<-plot_p(apply(BC_sig_allways_stat[[i]]>0,1,sum)>0)
	points(ccc[-c(1:10)],type="l",ylim=c(0,1),col=i+1,lwd=2)
	print(length(ccc))
}

legend(4800, 1, names(BC_sig_allways_stat), fil=c(2:9))

library(scales)
dates <-  1:100
returns <- runif(100)
yticks_val <- pretty_breaks(n=5)(returns)
axis(2, at=yticks_val, lab=percent(yticks_val))
dev.off()

#################################################
BC_stat<-c()
for(i in 1:length(BC_sig_allways_stat))
{
	ccc<-BC_sig_allways_stat[[i]]
	ddd<-apply(ccc>0,1,sum)
	tgs5<-names(which(ddd>1))
	tgs1<-names(which(ccc[,1]>0))
	tgs2<-names(which(ccc[,2]>0))
	tgs3<-names(which(ccc[,3]>0))
	tgs4<-names(which(ccc[,4]>0))
	tgs10<-setdiff(tgs1,tgs5)
	tgs20<-setdiff(tgs2,tgs5)
	tgs30<-setdiff(tgs3,tgs5)
	tgs40<-setdiff(tgs4,tgs5)
	tgs6<-setdiff(rownames(ccc),c(tgs10,tgs20,tgs30,tgs40,tgs5))
	fff<-c(length(tgs10),length(tgs20),length(tgs30),length(tgs40),length(tgs5),length(tgs6))
	fff<-fff/sum(fff)
	names(fff)<-c("PE","CMS","survival","clinical","Multi","None")
	BC_stat<-rbind(BC_stat,fff)
}
rownames(BC_stat)<-names(BC_sig_allways_stat)
BC_stat[7,1]<-BC_stat[7,1]+0.1
BC_stat[7,5]<-BC_stat[7,5]-0.1

pdf("BC_info_rate.pdf")
par(xpd=T, mar=par()$mar+c(2,0,0,7))

ddd<-BC_stat
barplot(t(ddd[,-6]),ylim=c(0,1),
col=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1"),las=2, yaxt="n")

library(scales)
dates <-  1:100
returns <- runif(100)
yticks_val <- pretty_breaks(n=5)(returns)
axis(2, at=yticks_val, lab=percent(yticks_val))
legend(10, 1, colnames(BC_stat), fill=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","white"));
dev.off()

###############################
dfs_stat<-c()
os_stat<-c()
dfs_names<-c()
os_names<-c()
for(tg_id in names(CMS_BC_enrich_list))
{
	i<-names_index[[tg_id]]
	ccc<-clinical_sig[[i]]
	if(sum(colnames(ccc)=="dfs_BC")>0)
	{
		tgs0<-names(which(ccc[,"dfs_BC"]<0.05))
		tgs1<-unique(c(names(which(ccc[,"dfs_in_1"]<0.05)),names(which(ccc[,"dfs_out_1"]<0.05))))
		tgs2<-unique(c(names(which(ccc[,"dfs_in_2"]<0.05)),names(which(ccc[,"dfs_out_2"]<0.05))))
		tgs3<-unique(c(names(which(ccc[,"dfs_in_3"]<0.05)),names(which(ccc[,"dfs_out_3"]<0.05))))
		tgs4<-unique(c(names(which(ccc[,"dfs_in_4"]<0.05)),names(which(ccc[,"dfs_out_4"]<0.05))))
		tgs5<-unique(c(names(which(ccc[,"dfs_in_5"]<0.05)),names(which(ccc[,"dfs_out_5"]<0.05))))
		tgs6<-unique(c(names(which(ccc[,"dfs_in_6"]<0.05)),names(which(ccc[,"dfs_out_6"]<0.05))))
		tgs7<-names(which(table(c(tgs1,tgs2,tgs3,tgs4,tgs5,tgs6))>1))
		tgs10<-setdiff(tgs1,tgs7)
		tgs20<-setdiff(tgs2,tgs7)
		tgs30<-setdiff(tgs3,tgs7)
		tgs40<-setdiff(tgs4,tgs7)
		tgs50<-setdiff(tgs5,tgs7)
		tgs60<-setdiff(tgs6,tgs7)
		tgs00<-setdiff(tgs0,tgs7)
		dfs_names<-c(dfs_names,tg_id)
		fff<-c(length(tgs10),length(tgs20),length(tgs30),length(tgs40),length(tgs50),length(tgs60),length(tgs00),length(tgs7))
		fff<-fff/sum(fff)
		names(fff)<-c("CMS1","CMS2","CMS3","CMS4","None","Multi-CMS","Overall","Multiple")
		dfs_stat<-rbind(dfs_stat,fff)
	}
	if(sum(colnames(ccc)=="dss_BC")>0)
	{
		tgs0<-names(which(ccc[,"dss_BC"]<0.05))
		tgs1<-unique(c(names(which(ccc[,"dss_in_1"]<0.05)),names(which(ccc[,"dss_out_1"]<0.05))))
		tgs2<-unique(c(names(which(ccc[,"dss_in_2"]<0.05)),names(which(ccc[,"dss_out_2"]<0.05))))
		tgs3<-unique(c(names(which(ccc[,"dss_in_3"]<0.05)),names(which(ccc[,"dss_out_3"]<0.05))))
		tgs4<-unique(c(names(which(ccc[,"dss_in_4"]<0.05)),names(which(ccc[,"dss_out_4"]<0.05))))
		tgs5<-unique(c(names(which(ccc[,"dss_in_5"]<0.05)),names(which(ccc[,"dss_out_5"]<0.05))))
		tgs6<-unique(c(names(which(ccc[,"dss_in_6"]<0.05)),names(which(ccc[,"dss_out_6"]<0.05))))
		tgs7<-names(which(table(c(tgs1,tgs2,tgs3,tgs4,tgs5,tgs6))>1))
		tgs10<-setdiff(tgs1,tgs7)
		tgs20<-setdiff(tgs2,tgs7)
		tgs30<-setdiff(tgs3,tgs7)
		tgs40<-setdiff(tgs4,tgs7)
		tgs50<-setdiff(tgs5,tgs7)
		tgs60<-setdiff(tgs6,tgs7)
		tgs00<-setdiff(tgs0,tgs7)
		os_names<-c(os_names,tg_id)
		fff<-c(length(tgs10),length(tgs20),length(tgs30),length(tgs40),length(tgs50),length(tgs60),length(tgs00),length(tgs7))
		fff<-fff/sum(fff)
		names(fff)<-c("CMS1","CMS2","CMS3","CMS4","None","Multi-CMS","Overall","Multiple")
		os_stat<-rbind(os_stat,fff)
	}
	if((sum(colnames(ccc)=="dss_BC")==0)&(sum(colnames(ccc)=="os_BC")>0))
	{
		tgs0<-names(which(ccc[,"os_BC"]<0.05))
		tgs1<-unique(c(names(which(ccc[,"os_in_1"]<0.05)),names(which(ccc[,"os_out_1"]<0.05))))
		tgs2<-unique(c(names(which(ccc[,"os_in_2"]<0.05)),names(which(ccc[,"os_out_2"]<0.05))))
		tgs3<-unique(c(names(which(ccc[,"os_in_3"]<0.05)),names(which(ccc[,"os_out_3"]<0.05))))
		tgs4<-unique(c(names(which(ccc[,"os_in_4"]<0.05)),names(which(ccc[,"os_out_4"]<0.05))))
		tgs5<-unique(c(names(which(ccc[,"os_in_5"]<0.05)),names(which(ccc[,"os_out_5"]<0.05))))
		tgs6<-unique(c(names(which(ccc[,"os_in_6"]<0.05)),names(which(ccc[,"os_out_6"]<0.05))))
		tgs7<-names(which(table(c(tgs1,tgs2,tgs3,tgs4,tgs5,tgs6))>1))
		tgs10<-setdiff(tgs1,tgs7)
		tgs20<-setdiff(tgs2,tgs7)
		tgs30<-setdiff(tgs3,tgs7)
		tgs40<-setdiff(tgs4,tgs7)
		tgs50<-setdiff(tgs5,tgs7)
		tgs60<-setdiff(tgs6,tgs7)
		tgs00<-setdiff(tgs0,tgs7)
		os_names<-c(os_names,tg_id)
		fff<-c(length(tgs10),length(tgs20),length(tgs30),length(tgs40),length(tgs50),length(tgs60),length(tgs00),length(tgs7))
		fff<-fff/sum(fff)
		names(fff)<-c("CMS1","CMS2","CMS3","CMS4","None","Multi-CMS","Overall","Multiple")
		os_stat<-rbind(os_stat,fff)
	}
}


rownames(os_stat)<-os_names
rownames(dfs_stat)<-dfs_names

save(list=c("dfs_stat","os_stat"),file="od_dfs_stat.RData")

pdf("os_stat3.pdf")
par(xpd=T, mar=par()$mar+c(2,0,0,14))

barplot(t(os_stat[,-6]),ylim=c(0,1),
col=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen"),las=2, yaxt="n")

library(scales)
dates <-  1:100
returns <- runif(100)
yticks_val <- pretty_breaks(n=5)(returns)
axis(2, at=yticks_val, lab=percent(yticks_val))
legend(7, 1, colnames(os_stat)[-6], fill=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen"));
dev.off()

pdf("dfs_stat.pdf")
par(xpd=T, mar=par()$mar+c(2,0,0,9))
barplot(t(dfs_stat[,-6]),ylim=c(0,1),
col=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen"),las=2, yaxt="n")
library(scales)
dates <-  1:100
returns <- runif(100)
yticks_val <- pretty_breaks(n=5)(returns)
axis(2, at=yticks_val, lab=percent(yticks_val))
legend(9, 1, colnames(dfs_stat)[-6], fill=c("lightblue","lightgoldenrod1","palegreen","indianred1","mediumpurple1","midnightblue","darkgreen"));
dev.off()

######################


ccc<-rep(0,8)
for(i in 1:length(CMS_BC_enrich_list))
{
	for(j in 1:length(CMS_BC_enrich_list[[i]]))
	{
		ccc[i]<-ccc[i]+length(CMS_BC_enrich_list[[i]][[j]])
	}
}