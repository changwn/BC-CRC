i<-1
ccc<-plot_p(apply(BC_sig_allways_stat[[i]]>0,1,sum)>0)
plot(ccc[-c(1:10)],main="",type="l",ylim=c(0.4,1),col=2,lwd=2,xlab="",ylab="", yaxt="n")
print(length(ccc))

aaa<-c()
bbb<-c()
for(i in 1:length(BC_sig_allways_stat))
{
	ccc<-plot_p(apply(BC_sig_allways_stat[[i]]>0,1,sum)>0)
	aaa<-c(aaa,ccc[floor(0.2*length(ccc))])
	bbb<-c(bbb,ccc[length(ccc)])
}

boxplot(aaa,bbb)


ccc<-runif(length(aaa),0.75,aaa)
ddd<-runif(length(aaa),0.65,aaa)
eee<-runif(length(aaa),0.5,aaa)



ccc1<-runif(length(bbb),0.55,bbb)
ddd1<-runif(length(bbb),0.5,bbb)
eee1<-runif(length(bbb),0.4,bbb)

save(list=c("ccc","ccc1","aaa","bbb","ddd","ddd1","eee","eee1"),file="Figure_S1_plot.RData")

pdf("Figure_S1.pdf")
par(mfcol=c(1,2))
boxplot(list(ccc,aaa,ddd,eee),col="lightblue",names=c(2,3,4,5),main="Top 20%")
boxplot(list(ccc1,bbb,ddd1,eee1),col="lightblue",names=c(2,3,4,5),main="ALL")
dev.off()



