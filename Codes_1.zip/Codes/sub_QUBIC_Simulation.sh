#!/bin/bash
cd '/home/xynlab/chizhang/Liang_Sen_CRC_Biclustering/JOB/QUBIC-R/Simulation/SM_5000_100_P_0.33_C_0.95_F_0.85/'
export LD_LIBRARY_PATH=/usr/local/gcc/5.3.0/lib64:$LD_LIBRARY_PATH
time /usr/local/R/3.3.0/bin/R CMD BATCH QUBIC_Simulation.R
