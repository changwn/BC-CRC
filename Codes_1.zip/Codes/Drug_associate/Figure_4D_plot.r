tg_file<-"try.pdf"
install.packages("circlize")
list.files()
load("Figure_4E_inputdata.RData")
ls()

colnames(tg_BCs_stat)
tg_data_c<-FU5_fff_new[,-1]

Drug_CMS_stat<-list(FU5_fff_new[,-1],OXA_fff_new[,-1],LEU_fff_new[,-1])

nn<-c(rownames(tg_BCs_stat))
for(i in 1:length(nn))
{
	nn[i]<-paste("BC",unlist(strsplit(nn[i],"BC_"))[2],sep="_")
}
left_d<-2
left_del<--1

cex0=1
cex01=0.7

pdf("Figure4D_try.pdf")
library(gplots)
library(circlize)
n <- nrow(tg_data_c)
m <- 15
rname <- nn
cname <- c(colnames(tg_BCs_stat),paste(colnames(tg_BCs_stat),"CMS"),"CMS1","CMS2","CMS3","CMS4","","","Drug\nResistance\nModule","","")
    rname <- as.character(rname)
    cname <- as.character(cname)
par(mar = c(0, 0, 0, 0), bg = "white",lwd=0.02)
plot.new()
plot.window(c(0, 2*m+5), c(0, 2*n+5), asp = 1)
bg0="white"
plot.window(c(-1+ 0.5,2*m + 5.5), c(0, 2*n + 15 ),asp = 1, xlab="", ylab="")
text(-left_d, (n:1)*2-0.5, rname, cex = cex0)
text((1:m)*2+0.5, rep(2*n + 4, m), cname, srt = 60,cex = cex01)

 rect(0.5-left_del, 0.5, m*2 + 0.5-left_del, n*2 + 0.5,lwd=0.3)  ##background color
   #segments(rep(0.5, n + 1)-left_del, 0.5 + (0:(n))*2, rep(2*m + 0.5, n + 1)-left_del,
   #  0.5 + (0:(n))*2, col = "black",lwd=0.3)
   segments(0.5 + c(0,3,6,10)*2-left_del, rep(0.5, 4), 0.5 + c(0,3,6,10)*2-left_del, rep(2*n + 0.5,  4), col = "black",lty=2,lwd=0.3)


qqq<-tg_BCs_stat
for(ii in 1:nrow(qqq))
{
	for(jj in 1:ncol(qqq))
	{
		c_c<-c((jj)*2+0.5,(n-ii+1)*2-0.5)
		if(qqq[ii,jj]==1)
		{
			text(c_c[1], c_c[2], "X", col = "black",cex=1.2,font=2)		
		}
	}
}


color_c<-c('lightblue','lightgoldenrod1','palegreen','indianred1')
for(i in 1:nrow(FU5_fff_new))
{
	#colors = c(-20:100)/100
	#my_palette <- colorRampPalette(c("white", color_c[k]))(n = 121)
	#tt_temp<-c()
	for(j in 1:3)
	{
		cc<-list()
		N<-0
		for(k in 1:ncol(Drug_CMS_stat[[j]]))
		{
			if(Drug_CMS_stat[[j]][i,k]<0.02)
			{
				N<-N+1
				cc[[N]]<-k
			}
		}
		c_c<-c((j+3)*2+0.5,(n-i+1)*2-0.5)
		if(length(cc)>0)
		{
			for(ii in 1:length(cc))
			{
				tg_radi<-0.8
				col_c<-color_c[cc[[ii]]]
				draw.sector(360/length(cc)*ii,360/length(cc)*(ii-1),center=c_c,rou1 = tg_radi,col=col_c,lwd=0.1)
			}
		}	
	}
}

ppp<-Drug_BC_samplewise_association_with_CMS_sign[,1:4]
for(ii in 1:nrow(ppp))
{
	colors = c(-20:100)/100
	my_palette1 <- colorRampPalette(c("white", "red"))(n = 121)
	my_palette2 <- colorRampPalette(c("white", "blue"))(n = 121)
	for(jj in 1:ncol(ppp))
	{
		c_c<-c((jj+6)*2+0.5,(n-ii+1)*2-0.5)
		if(ppp[ii,jj]<(-1))
		{
    			 rr<-min(abs(ppp[ii,jj])/2,1.8)/1.5
			 symbols(c_c[1], c_c[2], add = TRUE, inches = F,
		    	 squares=rr,lwd=0.1, bg = "red")
		}
		if(ppp[ii,jj]>1)
		{
			 rr<-min(abs(ppp[ii,jj])/2,1.8)/1.5
			 symbols(c_c[1], c_c[2], add = TRUE, inches = F,
		    	 squares=rr,lwd=0.1, bg = "blue")
		}
	}
}

dev.off()

