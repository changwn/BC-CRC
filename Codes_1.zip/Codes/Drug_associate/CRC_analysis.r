TCGA_data_t_dis<-data_t_dis

save(list=c("TCGA_data_t_dis","TCGA_sig_BCs_all","CMS_sample_list_all_GEO","coad_sur0","OXA_tg_BCs_new2_all","FU5_tg_BCs_new2_all","LEU_tg_BCs_new2_all","tg_samples_OXA_0","tg_samples_LEU_0","tg_samples_5FU_0","coad_sur"),file="TCGA_Drug_resistance_reanalysis_input.RData")


tg_BCs_cccc<-unique(c(OXA_tg_BCs_new2_all,FU5_tg_BCs_new2_all,LEU_tg_BCs_new2_all))
tg_BCs_ssss<-rep(0,length(tg_BCs_cccc))
names(tg_BCs_ssss)<-tg_BCs_cccc
tg_BCs_ssss1<-tg_BCs_ssss
tg_BCs_ssss2<-tg_BCs_ssss
tg_BCs_ssss3<-tg_BCs_ssss

tg_BCs_ssss[OXA_tg_BCs_new2_all]<-tg_BCs_ssss[OXA_tg_BCs_new2_all]+1.5
tg_BCs_ssss[FU5_tg_BCs_new2_all]<-tg_BCs_ssss[FU5_tg_BCs_new2_all]+1.8
tg_BCs_ssss[LEU_tg_BCs_new2_all]<-tg_BCs_ssss[LEU_tg_BCs_new2_all]+1.3

tg_BCs_ssss1[OXA_tg_BCs_new2_all]<-tg_BCs_ssss1[OXA_tg_BCs_new2_all]+1.5
tg_BCs_ssss2[FU5_tg_BCs_new2_all]<-tg_BCs_ssss2[FU5_tg_BCs_new2_all]+1.8
tg_BCs_ssss3[LEU_tg_BCs_new2_all]<-tg_BCs_ssss3[LEU_tg_BCs_new2_all]+1.3

tg_BCs_cccc1<-names(sort(tg_BCs_ssss,decreasing=T))

tg_BCs_stat<-cbind(tg_BCs_ssss2,tg_BCs_ssss1,tg_BCs_ssss3)
colnames(tg_BCs_stat)<-c("OXA","Fu5","FOLFOX ")
tg_BCs_stat<-tg_BCs_stat[tg_BCs_cccc1,]
tg_BCs_stat<-sign(tg_BCs_stat)
write.csv(tg_BCs_stat,"Drug_BC_overlap.csv")

ddd<-CMS_sample_list_all_GEO[[8]]

pdf("CMS_drug_resistance_BC_Association.pdf")
fff1_all<-c()
fff2_all<-c()
for(i in 1:length(tg_BCs_cccc1))
{
	tg_genes_c<-TCGA_sig_BCs_all[[tg_BCs_cccc1[[i]]]][[3]]
	tg_BC_level<-apply(TCGA_data_t_dis[tg_genes_c,],2,sum)
	fff1<-c()
	fff2<-c()
	values_all<-list()
	for(j in 1:length(ddd))
	{
		tg_s1<-intersect(names(tg_BC_level),ddd[[j]])
		tg_s2<-setdiff(names(tg_BC_level),tg_s1)
		fff1<-c(fff1,t.test(tg_BC_level[tg_s1],tg_BC_level[tg_s2])$p.value)
		fff2<-c(fff2,sign(mean(tg_BC_level[tg_s1])-mean(tg_BC_level[tg_s2])))
		values_all[[j]]<-tg_BC_level[tg_s1]
	}
	fff1_all<-rbind(fff1_all,fff1)
	fff2_all<-rbind(fff2_all,fff2)
	names(values_all)<-names(ddd)
	boxplot(values_all,col="lightblue",las=2,main=tg_BCs_cccc1[[i]])
}
dev.off()

Drug_BC_samplewise_association_with_CMS_sign<--log(fff1_all)/log(10)*(fff1_all<0.001)*fff2_all
rownames(Drug_BC_samplewise_association_with_CMS_sign)<-tg_BCs_cccc1
colnames(Drug_BC_samplewise_association_with_CMS_sign)<-names(ddd)


Drug_BC_samplewise_association_with_CMS_sign[tg_BCs_cccc1,]
##############

pdf("FU5_BCs_inside_CMS_diff.pdf")
tg_s_d<-tg_samples_5FU_0

fff_new<-c()
for(i in 1:length(tg_BCs_cccc1))
{
	tg_genes_c<-TCGA_sig_BCs_all[[tg_BCs_cccc1[[i]]]][[3]]
	tg_samples_c<-edit_colnames(TCGA_sig_BCs_all[[tg_BCs_cccc1[[i]]]][[2]])

	tg_BC_level<-apply(TCGA_data_t_dis[tg_genes_c,],2,sum)
	fff1<-c()
	fff2<-c()
	values_all<-list()
	par(mfcol=c(2,3))
	hist(tg_BC_level,col="lightblue",breaks=30)
		print(c(length(tg_s1_d_s),length(tg_s1_o_s)))
		aaa<-tg_BC_level[tg_s1_d_s]
		tgs1<-intersect(tg_samples_c,tg_s_d)
		tgs2<-setdiff(intersect(tg_s_d,colnames(TCGA_data_t_dis)),tg_samples_c)
		tg_aaa<-as.factor(c(rep(1,length(tgs1)),rep(0,length(tgs2))))
		names(tg_aaa)<-c(tgs1,tgs2)
		coad_sur0<-coad_sur[names(tg_aaa),]
		km.as.one<- survfit(coad_sur0$SurvObj~tg_aaa, conf.type = "none")
		sdf<-survdiff(coad_sur0$SurvObj~tg_aaa)
		pp1 <- round(1 - pchisq(sdf$chisq, length(sdf$n) - 1),6)
		plot(km.as.one,col=c(1,2),lwd=2,mark.time=TRUE,main=paste(i," All ","p = ",pp1,sep=""),cex.main=1.5)
		fff1<-c(fff1,pp1)

	for(j in 1:4)
	{
		tg_s1<-intersect(names(tg_BC_level),ddd[[j]])
		tg_s1_d<-intersect(tg_s_d,tg_s1)
		tg_s1_o<-setdiff(tg_s1,tg_s_d)
		tg_s1_d_s<-intersect(rownames(coad_sur),tg_s1_d)
		tg_s1_o_s<-intersect(rownames(coad_sur),tg_s1_o)
		print(c(length(tg_s1_d_s),length(tg_s1_o_s)))
		aaa<-tg_BC_level[tg_s1_d_s]
		tgs1<-intersect(tg_samples_c,tg_s1_d_s)
		tgs2<-setdiff(tg_s1_d_s,tg_samples_c)
		tg_aaa<-as.factor(c(rep(1,length(tgs1)),rep(0,length(tgs2))))
		names(tg_aaa)<-c(tgs1,tgs2)
		pp1<-2
		if(length(tgs1)>0)
		{
		coad_sur0<-coad_sur[names(tg_aaa),]
		km.as.one<- survfit(coad_sur0$SurvObj~tg_aaa, conf.type = "none")
		sdf<-survdiff(coad_sur0$SurvObj~tg_aaa)
		pp1 <- round(1 - pchisq(sdf$chisq, length(sdf$n) - 1),6)
		plot(km.as.one,col=c(1,2),lwd=2,mark.time=TRUE,main=paste(i," CMS_",j," ","p = ",pp1,sep=""),cex.main=1.5)
		}
		fff1<-c(fff1,pp1)
		#fff2<-c(fff2,sign(mean(tg_BC_level[tg_s1])-mean(tg_BC_level[tg_s2])))
		#values_all[[j]]<-tg_BC_level[tg_s1]
	}
	fff_new<-rbind(fff_new,fff1)
	#fff2_all<-rbind(fff2_all,fff2)
	#names(values_all)<-names(ddd)
	#boxplot(values_all,col="lightblue",las=2,main=tg_BCs_cccc1[[i]])
}
dev.off()

FU5_fff_new<-fff_new

(FU5_fff_new<0.05)*1

#########################



pdf("OXA_BCs_inside_CMS_diff.pdf")
tg_s_d<-tg_samples_OXA_0

fff_new<-c()
for(i in 1:length(tg_BCs_cccc1))
{
	tg_genes_c<-TCGA_sig_BCs_all[[tg_BCs_cccc1[[i]]]][[3]]
	tg_samples_c<-edit_colnames(TCGA_sig_BCs_all[[tg_BCs_cccc1[[i]]]][[2]])

	tg_BC_level<-apply(TCGA_data_t_dis[tg_genes_c,],2,sum)
	fff1<-c()
	fff2<-c()
	values_all<-list()
	par(mfcol=c(2,3))
	hist(tg_BC_level,col="lightblue",breaks=30)
		print(c(length(tg_s1_d_s),length(tg_s1_o_s)))
		aaa<-tg_BC_level[tg_s1_d_s]
		tgs1<-intersect(tg_samples_c,tg_s_d)
		tgs2<-setdiff(intersect(tg_s_d,colnames(TCGA_data_t_dis)),tg_samples_c)
		tg_aaa<-as.factor(c(rep(1,length(tgs1)),rep(0,length(tgs2))))
		names(tg_aaa)<-c(tgs1,tgs2)
		coad_sur0<-coad_sur[names(tg_aaa),]
		km.as.one<- survfit(coad_sur0$SurvObj~tg_aaa, conf.type = "none")
		sdf<-survdiff(coad_sur0$SurvObj~tg_aaa)
		pp1 <- round(1 - pchisq(sdf$chisq, length(sdf$n) - 1),6)
		plot(km.as.one,col=c(1,2),lwd=2,mark.time=TRUE,main=paste(i," All ","p = ",pp1,sep=""),cex.main=1.5)
		fff1<-c(fff1,pp1)

	for(j in 1:4)
	{
		tg_s1<-intersect(names(tg_BC_level),ddd[[j]])
		tg_s1_d<-intersect(tg_s_d,tg_s1)
		tg_s1_o<-setdiff(tg_s1,tg_s_d)
		tg_s1_d_s<-intersect(rownames(coad_sur),tg_s1_d)
		tg_s1_o_s<-intersect(rownames(coad_sur),tg_s1_o)
		print(c(length(tg_s1_d_s),length(tg_s1_o_s)))
		aaa<-tg_BC_level[tg_s1_d_s]
		tgs1<-intersect(tg_samples_c,tg_s1_d_s)
		tgs2<-setdiff(tg_s1_d_s,tg_samples_c)
		tg_aaa<-as.factor(c(rep(1,length(tgs1)),rep(0,length(tgs2))))
		names(tg_aaa)<-c(tgs1,tgs2)
		pp1<-2
		if(length(tgs1)>0)
		{
		coad_sur0<-coad_sur[names(tg_aaa),]
		km.as.one<- survfit(coad_sur0$SurvObj~tg_aaa, conf.type = "none")
		sdf<-survdiff(coad_sur0$SurvObj~tg_aaa)
		pp1 <- round(1 - pchisq(sdf$chisq, length(sdf$n) - 1),6)
		plot(km.as.one,col=c(1,2),lwd=2,mark.time=TRUE,main=paste(i," CMS_",j," ","p = ",pp1,sep=""),cex.main=1.5)
		}
		fff1<-c(fff1,pp1)
		#fff2<-c(fff2,sign(mean(tg_BC_level[tg_s1])-mean(tg_BC_level[tg_s2])))
		#values_all[[j]]<-tg_BC_level[tg_s1]
	}
	fff_new<-rbind(fff_new,fff1)
	#fff2_all<-rbind(fff2_all,fff2)
	#names(values_all)<-names(ddd)
	#boxplot(values_all,col="lightblue",las=2,main=tg_BCs_cccc1[[i]])
}
dev.off()

OXA_fff_new<-fff_new

(OXA_fff_new<0.05)*1

##########

pdf("LEU_BCs_inside_CMS_diff.pdf")
tg_s_d<-tg_samples_LEU_0

fff_new<-c()
for(i in 1:length(tg_BCs_cccc1))
{
	tg_genes_c<-TCGA_sig_BCs_all[[tg_BCs_cccc1[[i]]]][[3]]
	tg_samples_c<-edit_colnames(TCGA_sig_BCs_all[[tg_BCs_cccc1[[i]]]][[2]])

	tg_BC_level<-apply(TCGA_data_t_dis[tg_genes_c,],2,sum)
	fff1<-c()
	fff2<-c()
	values_all<-list()
	par(mfcol=c(2,3))
	hist(tg_BC_level,col="lightblue",breaks=30)
		print(c(length(tg_s1_d_s),length(tg_s1_o_s)))
		aaa<-tg_BC_level[tg_s1_d_s]
		tgs1<-intersect(tg_samples_c,tg_s_d)
		tgs2<-setdiff(intersect(tg_s_d,colnames(TCGA_data_t_dis)),tg_samples_c)
		pp1<-2
		if(length(tgs1)>0)
		{
		tg_aaa<-as.factor(c(rep(1,length(tgs1)),rep(0,length(tgs2))))
		names(tg_aaa)<-c(tgs1,tgs2)
		coad_sur0<-coad_sur[names(tg_aaa),]
		km.as.one<- survfit(coad_sur0$SurvObj~tg_aaa, conf.type = "none")
		sdf<-survdiff(coad_sur0$SurvObj~tg_aaa)
		pp1 <- round(1 - pchisq(sdf$chisq, length(sdf$n) - 1),6)
		plot(km.as.one,col=c(1,2),lwd=2,mark.time=TRUE,main=paste(i," All ","p = ",pp1,sep=""),cex.main=1.5)
		}
		fff1<-c(fff1,pp1)

	for(j in 1:4)
	{
		tg_s1<-intersect(names(tg_BC_level),ddd[[j]])
		tg_s1_d<-intersect(tg_s_d,tg_s1)
		tg_s1_o<-setdiff(tg_s1,tg_s_d)
		tg_s1_d_s<-intersect(rownames(coad_sur),tg_s1_d)
		tg_s1_o_s<-intersect(rownames(coad_sur),tg_s1_o)
		print(c(length(tg_s1_d_s),length(tg_s1_o_s)))
		aaa<-tg_BC_level[tg_s1_d_s]
		tgs1<-intersect(tg_samples_c,tg_s1_d_s)
		tgs2<-setdiff(tg_s1_d_s,tg_samples_c)
		tg_aaa<-as.factor(c(rep(1,length(tgs1)),rep(0,length(tgs2))))
		names(tg_aaa)<-c(tgs1,tgs2)
		pp1<-2
		if(length(tgs1)>0)
		{
		coad_sur0<-coad_sur[names(tg_aaa),]
		km.as.one<- survfit(coad_sur0$SurvObj~tg_aaa, conf.type = "none")
		sdf<-survdiff(coad_sur0$SurvObj~tg_aaa)
		pp1 <- round(1 - pchisq(sdf$chisq, length(sdf$n) - 1),6)
		plot(km.as.one,col=c(1,2),lwd=2,mark.time=TRUE,main=paste(i," CMS_",j," ","p = ",pp1,sep=""),cex.main=1.5)
		}
		fff1<-c(fff1,pp1)
		#fff2<-c(fff2,sign(mean(tg_BC_level[tg_s1])-mean(tg_BC_level[tg_s2])))
		#values_all[[j]]<-tg_BC_level[tg_s1]
	}
	fff_new<-rbind(fff_new,fff1)
	#fff2_all<-rbind(fff2_all,fff2)
	#names(values_all)<-names(ddd)
	#boxplot(values_all,col="lightblue",las=2,main=tg_BCs_cccc1[[i]])
}
dev.off()

LEU_fff_new<-fff_new

(LEU_fff_new<0.05)*1


FU5_fff_new
OXA_fff_new
LEU_fff_new

cbind(tg_BCs_stat,(FU5_fff_new[,2:5]<0.05)*1)
cbind(tg_BCs_stat,(OXA_fff_new[,2:5]<0.05)*1)
cbind(tg_BCs_stat,(LEU_fff_new[,2:5]<0.05)*1)

colnames(tg_BCs_stat)<-c("5-FU","OXA","FOLFOX")
save(list=c("tg_BCs_stat","FU5_fff_new","OXA_fff_new","LEU_fff_new",
"Drug_BC_samplewise_association_with_CMS_sign"),file="Figure_4E_inputdata.RData")


##########
Drug_BC_samplewise_association_with_CMS_sign<--log(fff1_all)/log(10)*(fff1_all<0.01)*fff2_all
rownames(Drug_BC_samplewise_association_with_CMS_sign)<-tg_BCs_cccc1
colnames(Drug_BC_samplewise_association_with_CMS_sign)<-names(ddd)

ggg<-Drug_BC_samplewise_association_with_CMS_sign
cbind(tg_BCs_stat,ggg[,1:4],(OXA_fff_new[,2:5]<0.01)*1)
cbind(tg_BCs_stat,ggg[,1:4],(FU5_fff_new[,2:5]<0.01)*1)
cbind(tg_BCs_stat,ggg[,1:4],(LEU_fff_new[,2:5]<0.01)*1)



