tg_file<-"try.pdf"
install.packages("circlize")
plot_tg_figure4D<-function(aaa,tg_file,cex0=0.3,cex01=0.3,left_d=15)
{
pdf(tg_file)
library(gplots)
library(circlize)
n <- length(tg_PE_sum[[1]])
m <- length(tg_PE_sum)
rname <- names(tg_PE_sum[[1]])
cname <- names(tg_PE_sum)
   if (is.null(rname))
        rname <- 1:2*n
    if (is.null(cname))
        cname <- 1:2*m
    rname <- as.character(rname)
    cname <- as.character(cname)
par(mar = c(0, 0, 0, 0), bg = "white",lwd=0.02)
plot.new()
plot.window(c(0, 2*m+5), c(0, 2*n+5), asp = 1)
bg0="white"
plot.window(c(-1+ 0.5,2*m + 5.5), c(0, 2*n + 15 ),asp = 1, xlab="", ylab="")
text(-left_d, (n:1)*2-1, rname, cex = cex0)
text((1:m)*2-1, rep(2*n + 4, m), cname, srt = 90,cex = cex01)
color_c<-c("midnightblue",'lightblue','lightgoldenrod1','palegreen','indianred1','mediumpurple1',"midnightblue",'lightblue','lightgoldenrod1','palegreen','indianred1','mediumpurple1',"midnightblue",'lightblue','lightgoldenrod1','palegreen','indianred1','mediumpurple1')
for(k in 1:m)
{
	colors = c(-20:100)/100
	my_palette <- colorRampPalette(c("white", color_c[k]))(n = 121)
	for(j in 1:n)
	{
		c_c<-c((k)*2-1,(n-j+1)*2-1)
		aaa0<-rbind(tg_PE_sum[[k]][[j]][[1]],tg_PE_sum[[k]][[j]][[2]])
		aaa20<-abs(log(aaa0[2,])/log(10))
		aaa20[which(aaa20>4)]<-4
		aaa20<-aaa20/4
		aaa10<-aaa0[1,]
		aaa10[which(aaa10>2)]<-2
		aaa10<-aaa10/2
		aaa<-rbind(aaa10,aaa20)
		aaa<-aaa[,order(-aaa[1,])]
		for(i in 1:ncol(aaa))
		{
			tg_radi<-aaa[1,i]
			col_c<-my_palette[floor(aaa[2,i]*100)+1]
			draw.sector(360/ncol(aaa)*i,360/ncol(aaa)*(i-1),center=c_c,rou1 = tg_radi,col=col_c)
		}
	}
}
dev.off()
}
