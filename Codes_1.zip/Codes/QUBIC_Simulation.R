# i********************************************
# * Name: sen@uga.edu
# * Date: Wed Nov 30 09:44:13 2016
# * Detail:
# *
# ********************************************
rm(list = ls())

library(QUBIC)
library(stringr)
library(dplyr)

run.name = "SM_5000_100_P_0.33_C_0.95_F_0.85"
v.split = strsplit(run.name, split = "_")[[1]]

mRow = as.numeric(v.split[2])
mCol = as.numeric(v.split[3])
CC = as.numeric(v.split[7])
FF = as.numeric(v.split[9])

args.o = 3000
args.f = FF
args.c = CC

root.path = paste0("/home/xynlab/chizhang/Liang_Sen_CRC_Biclustering/JOB/QUBIC-R/Simulation/",run.name, "/")
#root.path = paste0("~/Programming/CODE/CRC/Simulation/_data/SM_5000_100_P_0.33_C_1_F_0.85/")
setwd(root.path)

v.filename = dir(paste0(root.path,"data"))

# ********************************************
# * FUNCTION: output matrix data
# ********************************************
output_matrix <- function(data,file)
{
  data = as.matrix(data)
  data1<-data
  
  data1 = cbind(rownames(data), data)
  data1 = rbind(c("a",colnames(data)),data1)
  
  write.table(data1,file = file,col.names=F,row.names=F,quote=F,sep="\t", append= F)
}

# ********************************************
# * FUNCTION: read matrix data
# ********************************************
read_matrix <- function(file)
{
  data = read.csv(file = file,header = T,sep="\t")
  
  nmrow = data$a
  data = data[,-1]
  
  rownames(data) = nmrow
  
  data = as.matrix(data)
  return(data)
}

# ********************************************
# * Qubic
# ********************************************


for(iFile in v.filename){
{
  # iFile = v.filename[1]
  print(paste(iFile,"-c", args.c, "-f", args.f, "-o", args.o))
  # read data
  dat = read_matrix(file = paste0(root.path, "data/",iFile))
  
    # do QUBIC bicluster
    time1 = proc.time()
    res <- biclust::biclust(dat, method = BCQUD(), c = args.c, o = args.o, f = args.f)
    time = proc.time() - time1
    
    # give names
    colnames(res@RowxNumber) = paste0("BC", c(1:ncol(res@RowxNumber)))
    rownames(res@RowxNumber) = rownames(dat)
    
    colnames(res@NumberxCol) = colnames(dat)
    rownames(res@NumberxCol) = paste0("BC", c(1:ncol(res@RowxNumber)))
    
    res@RowxNumber[res@RowxNumber == "TRUE"] = "1"
    res@RowxNumber[res@RowxNumber == "FALSE"] = "0"
    
    res@NumberxCol[res@NumberxCol == "TRUE"] = "1"
    res@NumberxCol[res@NumberxCol == "FALSE"] = "0"
    
    # ********************************************
    # * Extract Data
    # ********************************************
    extract.dir = paste0(root.path,"Extract/")
    dir.create(extract.dir, recursive = T)
    
    d.row.number = res@RowxNumber
    d.number.col = res@NumberxCol
    
    n.BC = nrow(d.number.col)
    l.BC = vector(mode = 'list', length = n.BC)
    names(l.BC) = paste0("BC",seq(1,n.BC))
    
    all.gene = rownames(d.row.number)
    all.sample = colnames(d.number.col)
    
    for(i in 1:n.BC){
      
      samples = all.sample[which(d.number.col[i,] == "1")]
      genes = all.gene[which(d.row.number[,i] == "1")]
      
      gene.all = unlist(lapply(str_split(genes, pattern = "_"), function(x){x[1]}))
      gene.un = unique(gene.all)
      
      len = c(length(samples), length(genes))
      BC.matrix = dat[genes, samples]
      l.BC[[i]] = list(len = len, samples = samples, genes = genes, gene.all = gene.all, gene.un = gene.un, mat = BC.matrix)
    }
    l.BC = list(time = time, raw_matrix = dat, BC_list = l.BC)
    
    save(l.BC, file = paste0(extract.dir, iFile,".BC.RData"))
    gc()
  }
}


